---
name: Panka brand
description: Product name and official logo direction for the children's literacy app.
---

The project is named **Panka**.

The user-provided brand artwork includes a colorful open-book symbol, the Panka wordmark, and the tagline “Cada palabra abre un mundo.” A symbol-only variant was also supplied.

**Why:** The user stated on 2026-10-04 that the project is now called Panka and supplied these logo variants to use in the app.

**How to apply:** Use Panka in user-facing app copy and metadata. Use the full logo for brand display surfaces and the symbol-only version for compact app icons. Keep internal package identifiers and routes unchanged unless the user asks to rename them.