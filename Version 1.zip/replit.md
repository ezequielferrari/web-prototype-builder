# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Contains a visual prototype of **Panka** — an educational literacy and language development app for children aged 0-7.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5 (api-server, minimal)
- **Database**: PostgreSQL + Drizzle ORM (provisioned, not used in prototype)
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Artifacts

### literacy-app (React + Vite — main app)
- **Preview path**: `/`
- **Purpose**: Full visual prototype of a children's literacy app
- **Pages**: Splash, Onboarding, Home, Library, Reading (gamified), Families, Stories, Chat, Profile
- **Tech**: React, wouter, framer-motion, recharts, lucide-react, Tailwind CSS
- **Color palette**: Purple primary (#262 75% 62%), coral secondary, pink accent, light lavender background
- **Font**: Nunito (Google Fonts)
- **Data**: All hardcoded — no backend calls

### api-server (Express)
- **Preview path**: `/api`
- **Purpose**: Shared backend (currently only health check endpoint)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## Literacy App Structure

```
artifacts/literacy-app/src/
├── pages/
│   ├── splash.tsx        — animated splash screen (auto-redirects to onboarding)
│   ├── onboarding.tsx    — role and reader-name setup plus 3-step introduction
│   ├── home.tsx          — main dashboard with feature cards and progress
│   ├── library.tsx       — content library with age/level filters
│   ├── reading.tsx       — gamified reading with simulated recording/analysis
│   ├── families.tsx      — family guide with tips, checklist, weekly chart
│   ├── stories.tsx       — 5-step story creation wizard
│   ├── chat.tsx          — Lumi virtual friend chat
│   └── profile.tsx       — child profile with badges and reading chart
├── components/
│   └── layout/
│       └── mobile-container.tsx  — mobile shell with bottom navigation
└── App.tsx               — wouter routing with AnimatePresence
```
