import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Home, BookOpen, BookHeart, MessageCircle, User } from "lucide-react";

const navItems = [
  { path: "/home", icon: Home, label: "Inicio" },
  { path: "/library", icon: BookOpen, label: "Libros" },
  { path: "/stories", icon: BookHeart, label: "Cuentos" },
  { path: "/chat", icon: MessageCircle, label: "Lumi" },
  { path: "/profile", icon: User, label: "Perfil" },
];

export default function MobileContainer({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="relative w-full max-w-[430px] min-h-screen bg-background flex flex-col shadow-xl overflow-hidden">
        <div className="flex-1 overflow-y-auto pb-20">
          {children}
        </div>
        <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] bg-card border-t border-border z-50">
          <div className="flex items-center justify-around px-2 py-2">
            {navItems.map((item) => {
              const isActive = location === item.path || (location === "/" && item.path === "/home");
              return (
                <button
                  key={item.path}
                  data-testid={`nav-${item.label.toLowerCase()}`}
                  onClick={() => setLocation(item.path)}
                  className="flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-2xl transition-all duration-200 relative"
                >
                  {isActive && (
                    <motion.div
                      layoutId="navPill"
                      className="absolute inset-0 bg-primary/10 rounded-2xl"
                      initial={false}
                      transition={{ type: "spring", bounce: 0.3, duration: 0.4 }}
                    />
                  )}
                  <motion.div
                    animate={{ scale: isActive ? 1.15 : 1, y: isActive ? -2 : 0 }}
                    transition={{ type: "spring", bounce: 0.5, duration: 0.3 }}
                  >
                    <item.icon
                      size={22}
                      className={isActive ? "text-primary" : "text-muted-foreground"}
                      strokeWidth={isActive ? 2.5 : 1.8}
                    />
                  </motion.div>
                  <span className={`text-[10px] font-bold tracking-wide ${isActive ? "text-primary" : "text-muted-foreground"}`}>
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        </nav>
      </div>
    </div>
  );
}
