import { useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { readPankaProfile } from "@/lib/panka-profile";

export default function Splash() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const timer = setTimeout(
      () => setLocation(readPankaProfile() ? "/home" : "/onboarding"),
      2800,
    );
    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="w-full max-w-[430px] min-h-screen flex flex-col items-center justify-center relative overflow-hidden"
        style={{ background: "linear-gradient(160deg, hsl(262,75%,62%) 0%, hsl(280,65%,55%) 40%, hsl(340,80%,70%) 100%)" }}>

        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-white/10"
            style={{
              width: `${20 + (i * 15) % 60}px`,
              height: `${20 + (i * 15) % 60}px`,
              left: `${(i * 37) % 90}%`,
              top: `${(i * 53) % 90}%`,
            }}
            animate={{ y: [-10, 10, -10], opacity: [0.3, 0.7, 0.3] }}
            transition={{ duration: 2 + (i % 3), repeat: Infinity, delay: i * 0.2 }}
          />
        ))}

        <motion.h1
          initial={{ opacity: 0, scale: 0.88, y: 18 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: "spring", bounce: 0.35, duration: 0.8 }}
          className="mb-7 w-[min(88vw,390px)] overflow-hidden rounded-[28px] bg-white p-2 shadow-2xl"
          style={{ aspectRatio: "1.65 / 1" }}
        >
          <img
            src="/panka-logo.png"
            alt="Panka — Cada palabra abre un mundo"
            className="h-full w-full object-cover"
          />
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="mt-12 flex gap-2"
        >
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="w-2 h-2 bg-white/60 rounded-full"
              animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.25 }}
            />
          ))}
        </motion.div>
      </div>
    </div>
  );
}
