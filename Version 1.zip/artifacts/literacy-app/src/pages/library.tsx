import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Play, BookOpen, Headphones, Video } from "lucide-react";

const ageTabs = ["0-2", "3-5", "6-7"];
const levelTabs = ["Todos", "Nivel 1", "Nivel 2", "Nivel 3"];

const allBooks = [
  { id: 1, title: "Osito Dormilón", type: "cuento", level: "Nivel 1", age: "0-2", color: "from-amber-300 to-orange-400", progress: 100, duration: "5 min" },
  { id: 2, title: "Burbujas de Colores", type: "video", level: "Nivel 1", age: "0-2", color: "from-sky-300 to-blue-500", progress: 0, duration: "3 min" },
  { id: 3, title: "Mama Pato y sus Patitos", type: "audio", level: "Nivel 1", age: "0-2", color: "from-lime-300 to-emerald-400", progress: 45, duration: "8 min" },
  { id: 4, title: "El Leon y el Raton", type: "cuento", level: "Nivel 1", age: "3-5", color: "from-rose-300 to-pink-500", progress: 68, duration: "10 min" },
  { id: 5, title: "Los Tres Cerditos", type: "cuento", level: "Nivel 2", age: "3-5", color: "from-violet-300 to-purple-500", progress: 30, duration: "12 min" },
  { id: 6, title: "Canciones del Bosque", type: "audio", level: "Nivel 1", age: "3-5", color: "from-teal-300 to-cyan-500", progress: 0, duration: "15 min" },
  { id: 7, title: "Aventuras Espaciales", type: "video", level: "Nivel 2", age: "3-5", color: "from-indigo-400 to-violet-600", progress: 80, duration: "7 min" },
  { id: 8, title: "Caperucita Roja", type: "cuento", level: "Nivel 2", age: "6-7", color: "from-red-300 to-rose-500", progress: 20, duration: "18 min" },
  { id: 9, title: "El Principito", type: "audio", level: "Nivel 3", age: "6-7", color: "from-amber-400 to-yellow-500", progress: 0, duration: "25 min" },
  { id: 10, title: "Misterios del Oceano", type: "video", level: "Nivel 2", age: "6-7", color: "from-blue-400 to-cyan-600", progress: 55, duration: "10 min" },
  { id: 11, title: "Palabras Magicas", type: "cuento", level: "Nivel 3", age: "6-7", color: "from-fuchsia-300 to-pink-600", progress: 0, duration: "20 min" },
];

const typeIcon = { cuento: BookOpen, audio: Headphones, video: Video };

export default function Library() {
  const [ageTab, setAgeTab] = useState("3-5");
  const [levelTab, setLevelTab] = useState("Todos");
  const [favorites, setFavorites] = useState<number[]>([1, 5]);

  const filtered = allBooks.filter(
    (b) => b.age === ageTab && (levelTab === "Todos" || b.level === levelTab)
  );

  const toggleFav = (id: number) => {
    setFavorites((f) => f.includes(id) ? f.filter((x) => x !== id) : [...f, id]);
  };

  return (
    <div className="pt-10 pb-4">
      <div className="px-5 mb-6">
        <h1 className="text-2xl font-black text-foreground mb-1">Biblioteca</h1>
        <p className="text-muted-foreground text-sm font-medium">Descubre historias increibles</p>
      </div>

      <div className="px-5 mb-4">
        <div className="bg-muted rounded-2xl p-1 flex gap-1">
          {ageTabs.map((t) => (
            <button
              key={t}
              data-testid={`tab-age-${t}`}
              onClick={() => { setAgeTab(t); setLevelTab("Todos"); }}
              className="relative flex-1 py-2 text-sm font-bold rounded-xl transition-colors"
            >
              {ageTab === t && (
                <motion.div layoutId="agePill" className="absolute inset-0 bg-white rounded-xl shadow-sm" />
              )}
              <span className={`relative z-10 ${ageTab === t ? "text-primary" : "text-muted-foreground"}`}>
                {t} años
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex gap-2 px-5 mb-5 overflow-x-auto">
        {levelTabs.map((l) => (
          <button
            key={l}
            data-testid={`filter-level-${l}`}
            onClick={() => setLevelTab(l)}
            className={`flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-bold border transition-all ${levelTab === l ? "bg-primary text-white border-primary" : "bg-card text-muted-foreground border-border"}`}
          >
            {l}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={ageTab + levelTab}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="px-5 grid grid-cols-2 gap-3"
        >
          {filtered.map((book, i) => {
            const Icon = typeIcon[book.type as keyof typeof typeIcon];
            const isFav = favorites.includes(book.id);
            return (
              <motion.div
                key={book.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                data-testid={`card-book-${book.id}`}
                className="bg-card rounded-3xl overflow-hidden border border-border shadow-sm"
              >
                <div className={`relative h-36 bg-gradient-to-br ${book.color} flex items-center justify-center`}>
                  <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                    <Icon size={28} className="text-white" strokeWidth={1.8} />
                  </div>
                  <button
                    data-testid={`button-favorite-${book.id}`}
                    onClick={() => toggleFav(book.id)}
                    className="absolute top-2.5 right-2.5 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center shadow-sm"
                  >
                    <Heart size={15} className={isFav ? "text-rose-500 fill-rose-500" : "text-muted-foreground"} />
                  </button>
                  {book.progress > 0 && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/30">
                      <div className="h-full bg-white transition-all" style={{ width: `${book.progress}%` }} />
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <p className="font-black text-foreground text-xs leading-tight mb-1">{book.title}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground font-semibold">{book.duration}</span>
                    <motion.button
                      data-testid={`button-play-${book.id}`}
                      whileTap={{ scale: 0.9 }}
                      className="w-8 h-8 bg-primary rounded-full flex items-center justify-center shadow-md"
                    >
                      <Play size={13} className="text-white fill-white ml-0.5" />
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
