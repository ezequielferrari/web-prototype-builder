import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic, Star, Trophy, RefreshCw, ChevronRight } from "lucide-react";

type Phase = "idle" | "recording" | "analyzing" | "results";

const sentences = [
  "El sol brilla en el cielo azul y las flores bailan con el viento.",
  "La luna y las estrellas iluminan la noche oscura del bosque.",
  "El pequeno conejo corrio rapido por el campo verde.",
  "Maria leyo un cuento magico antes de dormir.",
];

const badges = [
  { label: "Lector Estrella", color: "from-amber-400 to-orange-500" },
  { label: "Super Fluido", color: "from-violet-500 to-purple-600" },
  { label: "Voz Clara", color: "from-emerald-400 to-teal-500" },
];

export default function Reading() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [sentenceIdx, setSentenceIdx] = useState(0);
  const [stars] = useState(4);
  const [metrics] = useState({ fluency: 88, pronunciation: 92, comprehension: 76 });
  const [earnedBadge] = useState(badges[0]);

  const startRecording = useCallback(() => {
    setPhase("recording");
    setTimeout(() => setPhase("analyzing"), 3200);
    setTimeout(() => setPhase("results"), 5400);
  }, []);

  const reset = () => {
    setSentenceIdx((i) => (i + 1) % sentences.length);
    setPhase("idle");
  };

  return (
    <div className="px-5 pt-10 pb-4 min-h-full">
      <div className="mb-6">
        <h1 className="text-2xl font-black text-foreground">Lectura en voz alta</h1>
        <p className="text-muted-foreground text-sm font-medium">Lee la frase y gana estrellas</p>
      </div>

      <AnimatePresence mode="wait">
        {phase === "idle" && (
          <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="bg-card border border-border rounded-3xl p-6 mb-6 shadow-sm">
              <p className="text-muted-foreground text-xs font-bold uppercase tracking-widest mb-3">Frase del dia</p>
              <p className="text-foreground text-xl font-black leading-relaxed">{sentences[sentenceIdx]}</p>
            </div>

            <div className="bg-muted/50 rounded-3xl p-4 mb-8">
              <p className="text-muted-foreground text-sm font-semibold text-center">Consejos: lee despacio, habla claro y usa tu voz mas bonita</p>
            </div>

            <div className="flex flex-col items-center">
              <motion.button
                data-testid="button-start-recording"
                whileTap={{ scale: 0.93 }}
                onClick={startRecording}
                className="w-36 h-36 rounded-full flex flex-col items-center justify-center gap-3 shadow-2xl text-white font-black text-sm"
                style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(340,80%,70%))" }}
              >
                <Mic size={40} strokeWidth={2} />
                Grabar lectura
              </motion.button>
              <p className="text-muted-foreground text-xs font-medium mt-4">Presiona para comenzar</p>
            </div>
          </motion.div>
        )}

        {phase === "recording" && (
          <motion.div key="recording" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col items-center pt-8">
            <div className="bg-rose-50 rounded-3xl p-6 w-full mb-8">
              <p className="text-rose-700 font-bold text-center text-sm mb-2">Grabando...</p>
              <p className="text-foreground text-lg font-black text-center leading-relaxed">{sentences[sentenceIdx]}</p>
            </div>
            <div className="relative flex items-center justify-center">
              {[0, 1, 2].map((i) => (
                <motion.div key={i} className="absolute rounded-full bg-rose-400/20"
                  animate={{ scale: [1, 1.6 + i * 0.4, 1], opacity: [0.6, 0, 0.6] }}
                  transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.4 }}
                  style={{ width: 80 + i * 40, height: 80 + i * 40 }}
                />
              ))}
              <div className="w-24 h-24 bg-rose-500 rounded-full flex items-center justify-center shadow-2xl relative z-10">
                <Mic size={36} className="text-white" strokeWidth={2} />
              </div>
            </div>
            <div className="flex gap-1.5 mt-8">
              {[...Array(12)].map((_, i) => (
                <motion.div key={i} className="w-1.5 bg-rose-400 rounded-full"
                  animate={{ height: [8, 8 + Math.random() * 28, 8] }}
                  transition={{ duration: 0.4 + Math.random() * 0.4, repeat: Infinity, delay: i * 0.08 }}
                />
              ))}
            </div>
          </motion.div>
        )}

        {phase === "analyzing" && (
          <motion.div key="analyzing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col items-center pt-16">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-20 h-20 rounded-full border-4 border-primary/20 border-t-primary mb-6"
            />
            <h3 className="text-xl font-black text-foreground mb-2">Analizando tu lectura...</h3>
            <p className="text-muted-foreground text-sm font-medium text-center">Calculando fluidez, pronunciacion y comprension</p>
          </motion.div>
        )}

        {phase === "results" && (
          <motion.div key="results" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", bounce: 0.6 }}
              className="text-center mb-6"
            >
              <div className="text-4xl font-black text-foreground mb-1">Excelente lectura!</div>
              <div className="flex justify-center gap-1 mt-2">
                {[...Array(5)].map((_, i) => (
                  <motion.div key={i} initial={{ scale: 0, rotate: -30 }}
                    animate={{ scale: i < stars ? 1 : 0.6, rotate: 0 }}
                    transition={{ delay: 0.1 + i * 0.1, type: "spring", bounce: 0.5 }}>
                    <Star size={28} className={i < stars ? "text-amber-400 fill-amber-400" : "text-muted-foreground/30"} />
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <div className="space-y-3 mb-6">
              {[
                { label: "Fluidez", value: metrics.fluency, color: "bg-violet-500" },
                { label: "Pronunciacion", value: metrics.pronunciation, color: "bg-orange-500" },
                { label: "Comprension", value: metrics.comprehension, color: "bg-emerald-500" },
              ].map((m, i) => (
                <div key={m.label} className="bg-card rounded-2xl p-4 border border-border">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-bold text-foreground">{m.label}</span>
                    <span className="text-sm font-black text-foreground">{m.value}%</span>
                  </div>
                  <div className="h-3 bg-muted rounded-full overflow-hidden">
                    <motion.div className={`h-full ${m.color} rounded-full`}
                      initial={{ width: 0 }}
                      animate={{ width: `${m.value}%` }}
                      transition={{ delay: 0.2 + i * 0.15, duration: 0.8, ease: "easeOut" }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className={`rounded-3xl p-4 mb-6 bg-gradient-to-br ${earnedBadge.color} flex items-center gap-4`}
            >
              <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                <Trophy size={28} className="text-white" strokeWidth={1.8} />
              </div>
              <div>
                <p className="text-white/80 text-xs font-semibold">Nuevo badge desbloqueado!</p>
                <p className="text-white font-black text-lg">{earnedBadge.label}</p>
              </div>
            </motion.div>

            <div className="flex gap-3">
              <motion.button
                data-testid="button-retry-reading"
                whileTap={{ scale: 0.95 }}
                onClick={reset}
                className="flex-1 py-3.5 rounded-2xl bg-muted font-bold text-foreground flex items-center justify-center gap-2"
              >
                <RefreshCw size={16} /> Otra vez
              </motion.button>
              <motion.button
                data-testid="button-next-reading"
                whileTap={{ scale: 0.95 }}
                onClick={reset}
                className="flex-1 py-3.5 rounded-2xl font-bold text-white flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(280,65%,55%))" }}
              >
                Siguiente <ChevronRight size={16} />
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
