import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, ChevronLeft, Sparkles, BookHeart } from "lucide-react";

const characters = [
  { name: "Luna", desc: "Una nena curiosa", color: "from-violet-400 to-purple-500", icon: "L" },
  { name: "Max", desc: "Un nino valiente", color: "from-blue-400 to-cyan-500", icon: "M" },
  { name: "Mia", desc: "Una artista creativa", color: "from-pink-400 to-rose-500", icon: "M" },
  { name: "Rex", desc: "Un dinosaurio amable", color: "from-emerald-400 to-teal-500", icon: "R" },
];

const settings = [
  { name: "El bosque", color: "from-emerald-400 to-green-600", icon: "🌲", iconText: "Bosque" },
  { name: "El espacio", color: "from-indigo-500 to-violet-700", icon: "✨", iconText: "Espacio" },
  { name: "El oceano", color: "from-sky-400 to-blue-600", icon: "🌊", iconText: "Oceano" },
  { name: "La ciudad", color: "from-amber-400 to-orange-500", icon: "🏙", iconText: "Ciudad" },
];

const decorations = [
  { label: "Estrella magica", color: "from-amber-300 to-yellow-500" },
  { label: "Cofre del tesoro", color: "from-amber-500 to-orange-600" },
  { label: "Varita encantada", color: "from-violet-400 to-purple-600" },
  { label: "Mapa secreto", color: "from-emerald-400 to-teal-500" },
];

export default function Stories() {
  const [step, setStep] = useState(0);
  const [character, setCharacter] = useState<string | null>(null);
  const [setting, setSetting] = useState<string | null>(null);
  const [adventure, setAdventure] = useState("");
  const [decoration, setDecoration] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const canNext = [
    !!character,
    !!setting,
    adventure.length > 2,
    !!decoration,
    true,
  ][step];

  const steps = ["Personaje", "Escenario", "Aventura", "Decoracion", "Mi cuento"];

  return (
    <div className="px-5 pt-10 pb-4 min-h-full flex flex-col">
      <div className="mb-5">
        <h1 className="text-2xl font-black text-foreground">Crear mi cuento</h1>
        <div className="flex gap-1.5 mt-3">
          {steps.map((s, i) => (
            <div key={s} className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${i <= step ? "bg-primary" : "bg-muted"}`} />
          ))}
        </div>
        <p className="text-muted-foreground text-xs font-bold mt-2">Paso {step + 1} de {steps.length}: {steps[step]}</p>
      </div>

      <div className="flex-1">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div key="s0" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }}>
              <p className="font-black text-foreground text-lg mb-4">Quien es el protagonista?</p>
              <div className="grid grid-cols-2 gap-3">
                {characters.map((c) => (
                  <motion.button
                    key={c.name}
                    data-testid={`button-character-${c.name}`}
                    whileTap={{ scale: 0.93 }}
                    onClick={() => setCharacter(c.name)}
                    className={`rounded-3xl p-5 border-2 transition-all ${character === c.name ? "border-primary bg-primary/5" : "border-border bg-card"}`}
                  >
                    <div className={`w-16 h-16 bg-gradient-to-br ${c.color} rounded-2xl flex items-center justify-center text-white font-black text-2xl mb-3 mx-auto shadow-md`}>
                      {c.icon}
                    </div>
                    <p className="font-black text-foreground text-sm">{c.name}</p>
                    <p className="text-muted-foreground text-xs font-medium">{c.desc}</p>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div key="s1" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }}>
              <p className="font-black text-foreground text-lg mb-4">Donde ocurre la historia?</p>
              <div className="grid grid-cols-2 gap-3">
                {settings.map((s) => (
                  <motion.button
                    key={s.name}
                    data-testid={`button-setting-${s.name}`}
                    whileTap={{ scale: 0.93 }}
                    onClick={() => setSetting(s.name)}
                    className={`rounded-3xl overflow-hidden border-2 transition-all ${setting === s.name ? "border-primary" : "border-transparent"}`}
                  >
                    <div className={`h-28 bg-gradient-to-br ${s.color} flex flex-col items-center justify-center gap-2`}>
                      <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                        <span className="text-white font-black text-xs">{s.iconText}</span>
                      </div>
                    </div>
                    <div className="bg-card p-2.5">
                      <p className="font-black text-foreground text-sm">{s.name}</p>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="s2" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }}>
              <p className="font-black text-foreground text-lg mb-2">Que encontro en su aventura?</p>
              <div className="bg-primary/10 rounded-2xl p-4 mb-4">
                <p className="text-primary font-bold text-sm leading-relaxed">
                  Un dia, <span className="font-black">{character || "..."}</span> fue a {setting || "..."} y encontro...
                </p>
              </div>
              <textarea
                data-testid="input-adventure"
                value={adventure}
                onChange={(e) => setAdventure(e.target.value)}
                placeholder="un objeto magico, un nuevo amigo, un tesoro..."
                className="w-full h-36 bg-card border-2 border-border rounded-2xl p-4 text-foreground font-semibold text-sm resize-none focus:outline-none focus:border-primary transition-colors"
              />
              <div className="mt-3">
                <p className="text-muted-foreground text-xs font-bold mb-2">Palabras sugeridas:</p>
                <div className="flex flex-wrap gap-2">
                  {["un dragon amigable", "una llave de oro", "un libro volador", "una flor que hablaba"].map((w) => (
                    <button key={w} data-testid={`button-suggestion-${w}`}
                      onClick={() => setAdventure(adventure + (adventure ? ", " : "") + w)}
                      className="bg-primary/10 text-primary text-xs font-bold px-3 py-1.5 rounded-full">
                      {w}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="s3" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }}>
              <p className="font-black text-foreground text-lg mb-4">Agrega un elemento especial</p>
              <div className="grid grid-cols-2 gap-3">
                {decorations.map((d) => (
                  <motion.button
                    key={d.label}
                    data-testid={`button-decoration-${d.label}`}
                    whileTap={{ scale: 0.93 }}
                    onClick={() => setDecoration(d.label)}
                    className={`rounded-3xl border-2 overflow-hidden transition-all ${decoration === d.label ? "border-primary" : "border-border"}`}
                  >
                    <div className={`h-20 bg-gradient-to-br ${d.color} flex items-center justify-center`}>
                      <Sparkles size={28} className="text-white" strokeWidth={1.8} />
                    </div>
                    <div className="bg-card p-3">
                      <p className="font-black text-foreground text-xs">{d.label}</p>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div key="s4" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
              {!saved ? (
                <>
                  <div className="bg-card border border-border rounded-3xl p-6 mb-6 shadow-sm">
                    <div className="flex items-center gap-2 mb-4">
                      <BookHeart size={20} className="text-primary" />
                      <h2 className="font-black text-foreground text-base">Mi cuento creado</h2>
                    </div>
                    <div className="h-32 rounded-2xl bg-gradient-to-br from-violet-300 to-pink-400 mb-4 flex items-center justify-center shadow-md">
                      <p className="text-white font-black text-xl text-center px-4">La aventura de {character}</p>
                    </div>
                    <p className="text-foreground font-semibold text-sm leading-relaxed">
                      Un dia, <strong>{character}</strong> fue a <strong>{setting}</strong> y encontro {adventure || "algo increible"}. Y con su <strong>{decoration}</strong>, todo se hizo posible. Fue un dia que {character} nunca olvidaria.
                    </p>
                  </div>
                  <motion.button
                    data-testid="button-save-story"
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSaved(true)}
                    className="w-full py-4 rounded-2xl font-black text-white text-lg shadow-lg"
                    style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(340,80%,70%))" }}
                  >
                    Guardar mi cuento
                  </motion.button>
                </>
              ) : (
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", bounce: 0.6 }}
                  className="text-center pt-8">
                  <div className="flex justify-center gap-1 mb-4">
                    {[...Array(12)].map((_, i) => (
                      <motion.div key={i}
                        className="w-2 h-2 rounded-full"
                        style={{ background: ["hsl(262,75%,62%)", "hsl(22,90%,65%)", "hsl(340,80%,70%)", "hsl(160,60%,50%)"][i % 4] }}
                        animate={{ y: [-20, 0, -20], opacity: [0, 1, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.12 }}
                      />
                    ))}
                  </div>
                  <h3 className="text-3xl font-black text-foreground mb-2">Cuento guardado!</h3>
                  <p className="text-muted-foreground font-semibold mb-6">Tu historia esta lista para compartir</p>
                  <motion.button whileTap={{ scale: 0.95 }} onClick={() => { setStep(0); setCharacter(null); setSetting(null); setAdventure(""); setDecoration(null); setSaved(false); }}
                    data-testid="button-new-story"
                    className="px-8 py-3.5 rounded-2xl font-black text-white"
                    style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(280,65%,55%))" }}>
                    Crear otro cuento
                  </motion.button>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {!saved && (
        <div className="flex gap-3 mt-6">
          {step > 0 && (
            <motion.button
              data-testid="button-prev-step"
              whileTap={{ scale: 0.95 }}
              onClick={() => setStep(step - 1)}
              className="flex-1 py-3.5 rounded-2xl bg-muted font-bold text-foreground flex items-center justify-center gap-2"
            >
              <ChevronLeft size={16} /> Atras
            </motion.button>
          )}
          {step < 4 && (
            <motion.button
              data-testid="button-next-step"
              whileTap={{ scale: 0.95 }}
              onClick={() => canNext && setStep(step + 1)}
              className={`flex-1 py-3.5 rounded-2xl font-bold text-white flex items-center justify-center gap-2 transition-opacity ${canNext ? "opacity-100" : "opacity-40"}`}
              style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(280,65%,55%))" }}
            >
              Siguiente <ChevronRight size={16} />
            </motion.button>
          )}
        </div>
      )}
    </div>
  );
}
