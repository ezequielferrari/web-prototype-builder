import { motion } from "framer-motion";
import { Star, Trophy, Flame, BookOpen, Clock, Target } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";

const readingData = [
  { day: "Lun", min: 12 },
  { day: "Mar", min: 20 },
  { day: "Mie", min: 8 },
  { day: "Jue", min: 25 },
  { day: "Vie", min: 18 },
  { day: "Sab", min: 30 },
  { day: "Dom", min: 22 },
];

const badges = [
  { label: "Lector Estrella", color: "from-amber-400 to-orange-500", earned: true },
  { label: "Super Fluido", color: "from-violet-500 to-purple-600", earned: true },
  { label: "Voz Clara", color: "from-emerald-400 to-teal-500", earned: true },
  { label: "Explorador", color: "from-sky-400 to-blue-500", earned: true },
  { label: "Inventor", color: "from-pink-400 to-rose-500", earned: false },
  { label: "Maestro", color: "from-indigo-400 to-violet-600", earned: false },
];

const stats = [
  { icon: BookOpen, label: "Cuentos leidos", value: "47", color: "text-violet-500", bg: "bg-violet-50" },
  { icon: Clock, label: "Horas de lectura", value: "12h", color: "text-orange-500", bg: "bg-orange-50" },
  { icon: Flame, label: "Racha actual", value: "7 dias", color: "text-rose-500", bg: "bg-rose-50" },
  { icon: Target, label: "Meta semanal", value: "87%", color: "text-emerald-500", bg: "bg-emerald-50" },
];

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } }
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const } }
};

export default function Profile() {
  return (
    <div className="px-5 pt-10 pb-4">
      <motion.div initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-4 mb-6">
        <div className="relative">
          <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-white font-black text-3xl shadow-xl"
            style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(340,80%,70%))" }}>
            S
          </div>
          <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-amber-400 rounded-full border-2 border-background flex items-center justify-center">
            <Star size={13} className="text-white fill-white" />
          </div>
        </div>
        <div>
          <h1 className="text-2xl font-black text-foreground">Sofia</h1>
          <div className="flex items-center gap-2 mt-1">
            <div className="bg-primary/10 rounded-full px-3 py-1 flex items-center gap-1.5">
              <Trophy size={13} className="text-primary" />
              <span className="text-primary font-black text-xs">Nivel 2 - Lectora</span>
            </div>
          </div>
          <div className="flex items-center gap-1 mt-1.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={14} className={i < 4 ? "text-amber-400 fill-amber-400" : "text-muted-foreground/30"} />
            ))}
            <span className="text-muted-foreground text-xs font-semibold ml-1">4.0 / 5.0</span>
          </div>
        </div>
      </motion.div>

      <motion.div variants={container} initial="hidden" animate="show" className="grid grid-cols-2 gap-3 mb-6">
        {stats.map((s) => (
          <motion.div key={s.label} variants={item} className={`${s.bg} rounded-3xl p-4 border border-border/30`}>
            <div className={`w-10 h-10 bg-white rounded-2xl flex items-center justify-center mb-2 shadow-sm`}>
              <s.icon size={18} className={s.color} strokeWidth={2} />
            </div>
            <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
            <p className="text-muted-foreground text-xs font-semibold">{s.label}</p>
          </motion.div>
        ))}
      </motion.div>

      <div className="bg-card border border-border rounded-3xl p-5 mb-6 shadow-sm">
        <h2 className="font-black text-foreground text-base mb-4">Minutos de lectura esta semana</h2>
        <ResponsiveContainer width="100%" height={130}>
          <LineChart data={readingData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(250,20%,90%)" />
            <XAxis dataKey="day" tick={{ fontSize: 10, fontWeight: 700, fill: "hsl(262,30%,40%)" }} axisLine={false} tickLine={false} />
            <YAxis hide />
            <Tooltip
              contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 4px 12px rgba(0,0,0,0.1)", fontSize: 12, fontWeight: 700 }}
              formatter={(v: number) => [`${v} min`, "Lectura"]}
            />
            <Line
              type="monotone"
              dataKey="min"
              stroke="hsl(262,75%,62%)"
              strokeWidth={3}
              dot={{ fill: "hsl(262,75%,62%)", strokeWidth: 0, r: 5 }}
              activeDot={{ r: 7, fill: "hsl(340,80%,70%)" }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-black text-foreground text-base">Mis badges</h2>
          <span className="text-primary text-xs font-bold">{badges.filter((b) => b.earned).length}/{badges.length} obtenidos</span>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {badges.map((badge, i) => (
            <motion.div
              key={badge.label}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: badge.earned ? 1 : 0.4, scale: 1 }}
              transition={{ delay: i * 0.08, type: "spring", bounce: 0.4 }}
              data-testid={`badge-${badge.label.toLowerCase().replace(/\s+/g, "-")}`}
              className="flex flex-col items-center gap-2"
            >
              <div className={`w-16 h-16 bg-gradient-to-br ${badge.color} rounded-2xl flex items-center justify-center shadow-md ${!badge.earned ? "grayscale" : ""}`}>
                <Trophy size={26} className="text-white" strokeWidth={1.8} />
              </div>
              <p className="text-foreground text-xs font-bold text-center leading-tight">{badge.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
