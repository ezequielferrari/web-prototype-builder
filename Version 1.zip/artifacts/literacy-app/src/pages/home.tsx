import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { BookOpen, Mic, BookHeart, MessageCircle, Users, Star, Flame, Bell } from "lucide-react";
import { readPankaProfile } from "@/lib/panka-profile";

const featureCards = [
  { path: "/library", icon: BookOpen, label: "Biblioteca", desc: "Cuentos y audiolibros", color: "from-violet-500 to-purple-600", bg: "bg-violet-50" },
  { path: "/reading", icon: Mic, label: "Lectura", desc: "Lee y gana estrellas", color: "from-orange-400 to-rose-500", bg: "bg-orange-50" },
  { path: "/stories", icon: BookHeart, label: "Cuentos", desc: "Crea tu historia", color: "from-pink-400 to-rose-400", bg: "bg-pink-50" },
  { path: "/chat", icon: MessageCircle, label: "Lumi", desc: "Tu amigo virtual", color: "from-emerald-400 to-teal-500", bg: "bg-emerald-50" },
];

const recentBooks = [
  { title: "El Leon y el Raton", level: "Nivel 1", color: "from-amber-300 to-orange-400" },
  { title: "Los Tres Cerditos", level: "Nivel 2", color: "from-pink-300 to-rose-400" },
  { title: "Caperucita Roja", level: "Nivel 2", color: "from-violet-300 to-purple-400" },
];

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } }
};
const item = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, bounce: 0.4 } }
};

export default function Home() {
  const [, setLocation] = useLocation();
  const profile = readPankaProfile();
  const greeting = profile?.role === "adult" ? "Una nueva aventura para" : "¡Hola,";
  const readerName = profile?.name ?? "explorador/a";

  return (
    <div className="px-5 pt-10 pb-4">
      <motion.div initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between mb-6">
        <div>
          <p className="text-muted-foreground text-sm font-semibold">{greeting}</p>
          <h1 className="text-2xl font-black text-foreground">{readerName}!</h1>
        </div>
        <div className="flex items-center gap-3">
          <motion.button
            data-testid="button-notifications"
            whileTap={{ scale: 0.92 }}
            className="w-10 h-10 bg-card rounded-2xl flex items-center justify-center shadow-sm border border-border"
          >
            <Bell size={18} className="text-muted-foreground" />
          </motion.button>
          <div className="w-10 h-10 rounded-2xl flex items-center justify-center font-black text-white text-lg shadow-md"
            style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(340,80%,70%))" }}>
            {profile?.name.charAt(0).toUpperCase() ?? "P"}
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="rounded-3xl p-5 mb-6 relative overflow-hidden"
        style={{ background: "linear-gradient(135deg, hsl(262,75%,62%) 0%, hsl(280,65%,55%) 50%, hsl(340,80%,70%) 100%)" }}
      >
        <div className="absolute right-4 top-4 opacity-20">
          <Star size={80} className="text-white" />
        </div>
        <div className="flex items-center gap-4">
          <div className="relative w-16 h-16">
            <svg viewBox="0 0 64 64" className="w-full h-full -rotate-90">
              <circle cx="32" cy="32" r="26" fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth="6" />
              <circle cx="32" cy="32" r="26" fill="none" stroke="white" strokeWidth="6"
                strokeDasharray={`${2 * Math.PI * 26 * 0.68} ${2 * Math.PI * 26 * 0.32}`}
                strokeLinecap="round" />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center text-white font-black text-sm">68%</span>
          </div>
          <div>
            <p className="text-white/80 text-sm font-semibold">Progreso de hoy</p>
            <p className="text-white font-black text-xl">4 de 6 actividades</p>
            <p className="text-white/70 text-xs font-medium mt-0.5">Sigue adelante, ya casi llegas!</p>
          </div>
        </div>
        <div className="mt-4 flex gap-3">
          <div className="flex-1 bg-white/20 rounded-2xl px-3 py-2 text-center">
            <p className="text-white font-black text-lg">12</p>
            <p className="text-white/80 text-xs font-semibold">min lectura</p>
          </div>
          <div className="flex-1 bg-white/20 rounded-2xl px-3 py-2 text-center">
            <p className="text-white font-black text-lg">3</p>
            <p className="text-white/80 text-xs font-semibold">cuentos hoy</p>
          </div>
          <div className="flex-1 bg-white/20 rounded-2xl px-3 py-2 text-center flex flex-col items-center">
            <div className="flex items-center gap-0.5">
              <Flame size={16} className="text-yellow-300 fill-yellow-300" />
              <p className="text-white font-black text-lg">7</p>
            </div>
            <p className="text-white/80 text-xs font-semibold">dias seguidos</p>
          </div>
        </div>
      </motion.div>

      <motion.h2 variants={item} initial="hidden" animate="show" className="text-lg font-black text-foreground mb-3">
        Actividades
      </motion.h2>
      <motion.div variants={container} initial="hidden" animate="show" className="grid grid-cols-2 gap-3 mb-6">
        {featureCards.map((card) => (
          <motion.button
            key={card.path}
            variants={item}
            data-testid={`button-feature-${card.label.toLowerCase()}`}
            whileTap={{ scale: 0.94 }}
            onClick={() => setLocation(card.path)}
            className={`${card.bg} rounded-3xl p-4 text-left flex flex-col gap-3 border border-border/50 shadow-sm`}
          >
            <div className={`w-12 h-12 bg-gradient-to-br ${card.color} rounded-2xl flex items-center justify-center shadow-md`}>
              <card.icon size={24} className="text-white" strokeWidth={1.8} />
            </div>
            <div>
              <p className="font-black text-foreground text-sm">{card.label}</p>
              <p className="text-muted-foreground text-xs font-medium">{card.desc}</p>
            </div>
          </motion.button>
        ))}
      </motion.div>

      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-black text-foreground">Continuar leyendo</h2>
        <button data-testid="button-see-all-books" onClick={() => setLocation("/library")}
          className="text-primary text-sm font-bold">Ver todos</button>
      </div>
      <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1">
        {recentBooks.map((book, i) => (
          <motion.button
            key={i}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 + i * 0.1 }}
            data-testid={`card-book-${i}`}
            whileTap={{ scale: 0.96 }}
            className="flex-shrink-0 w-36"
          >
            <div className={`w-full h-44 rounded-2xl bg-gradient-to-br ${book.color} mb-2 flex items-end p-3 shadow-md`}>
              <div className="bg-white/20 rounded-xl px-2 py-0.5">
                <p className="text-white text-xs font-bold">{book.level}</p>
              </div>
            </div>
            <p className="text-foreground text-xs font-bold leading-tight text-left">{book.title}</p>
          </motion.button>
        ))}
      </div>

      <motion.button
        data-testid="button-families"
        whileTap={{ scale: 0.96 }}
        onClick={() => setLocation("/families")}
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-4 w-full flex items-center gap-4 bg-card border border-border rounded-3xl p-4 shadow-sm"
      >
        <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-2xl flex items-center justify-center shadow-md">
          <Users size={24} className="text-white" strokeWidth={1.8} />
        </div>
        <div className="text-left">
          <p className="font-black text-foreground text-sm">Guia para familias</p>
          <p className="text-muted-foreground text-xs font-medium">Consejos y actividades para casa</p>
        </div>
        <div className="ml-auto">
          <div className="w-7 h-7 bg-primary/10 rounded-full flex items-center justify-center">
            <span className="text-primary font-black text-sm">›</span>
          </div>
        </div>
      </motion.button>
    </div>
  );
}
