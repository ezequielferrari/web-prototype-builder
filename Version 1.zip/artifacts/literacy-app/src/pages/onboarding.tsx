import { useState, type FormEvent } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { BookOpen, Mic, Users, ChevronRight, Check } from "lucide-react";
import { readPankaProfile, savePankaProfile, type PankaRole } from "@/lib/panka-profile";

const steps = [
  {
    icon: BookOpen,
    color: "from-violet-500 to-purple-600",
    bg: "bg-violet-50",
    title: "Biblioteca de cuentos",
    desc: "Cientos de cuentos, audiolibros y videos educativos para cada edad. Filtra por nivel y descubre nuevas historias cada dia.",
  },
  {
    icon: Mic,
    color: "from-orange-400 to-rose-500",
    bg: "bg-orange-50",
    title: "Lectura gamificada",
    desc: "Gana estrellas y badges leyendo en voz alta. Nuestro sistema analiza la fluidez y da feedback inmediato con mensajes positivos.",
  },
  {
    icon: Users,
    color: "from-emerald-400 to-teal-500",
    bg: "bg-emerald-50",
    title: "Para toda la familia",
    desc: "Guia especial para mamas, papas y cuidadores con consejos, actividades y seguimiento del progreso de tu nino.",
  },
];

export default function Onboarding() {
  const [step, setStep] = useState(0);
  const savedProfile = readPankaProfile();
  const [name, setName] = useState(savedProfile?.name ?? "");
  const [role, setRole] = useState<PankaRole | null>(savedProfile?.role ?? null);
  const [saveError, setSaveError] = useState("");
  const [, setLocation] = useLocation();
  const totalSteps = steps.length + 1;
  const isProfileStep = step === 0;
  const currentStep = steps[Math.max(0, step - 1)];

  const next = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (isProfileStep) {
      const trimmedName = name.trim();
      if (!role || !trimmedName) return;

      try {
        savePankaProfile({ name: trimmedName, role });
        setName(trimmedName);
        setSaveError("");
        setStep(1);
      } catch {
        setSaveError("No pudimos guardar el perfil. Revisa el almacenamiento de tu navegador e inténtalo otra vez.");
      }
      return;
    }

    if (step < totalSteps - 1) setStep(step + 1);
    else setLocation("/home");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <form
        className="w-full max-w-[430px] min-h-screen flex flex-col px-6 pt-12 pb-10"
        onSubmit={next}
      >
        <div className="flex justify-between items-center mb-8">
          <div
            className="flex gap-2"
            role="progressbar"
            aria-label="Progreso de bienvenida"
            aria-valuemin={1}
            aria-valuemax={totalSteps}
            aria-valuenow={step + 1}
          >
            {Array.from({ length: totalSteps }, (_, i) => (
              <motion.div
                key={i}
                animate={{ width: i === step ? 28 : 8, opacity: i <= step ? 1 : 0.3 }}
                transition={{ duration: 0.3 }}
                className="h-2 bg-primary rounded-full"
              />
            ))}
          </div>
          {step > 0 && (
            <button
              type="button"
              data-testid="button-skip-onboarding"
              onClick={() => setLocation("/home")}
              className="text-muted-foreground text-sm font-semibold"
            >
              Saltar intro
            </button>
          )}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 60 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -60 }}
            transition={{ duration: 0.35 }}
            className="flex-1 flex flex-col"
          >
            {isProfileStep ? (
              <div className="flex-1 flex flex-col justify-center py-3">
                <div className="mb-6">
                  <span className="inline-flex rounded-full bg-primary/10 px-3 py-1 text-xs font-extrabold uppercase tracking-wide text-primary mb-3">
                    Bienvenida a Panka
                  </span>
                  <h1 className="text-3xl font-black text-foreground mb-2 leading-tight">
                    ¿Quién va a usar Panka?
                  </h1>
                  <p className="text-muted-foreground text-sm font-medium leading-relaxed">
                    Elige una opción y personalizamos el comienzo.
                  </p>
                </div>

                <div className="grid gap-3 mb-5" role="radiogroup" aria-label="Elige quién usará Panka">
                  {[
                    {
                      value: "adult" as const,
                      label: "Soy adulto",
                      description: "Acompaño a una niña o un niño.",
                      icon: Users,
                    },
                    {
                      value: "child" as const,
                      label: "Soy niño/a",
                      description: "Quiero leer, jugar y crear cuentos.",
                      icon: BookOpen,
                    },
                  ].map((option) => {
                    const RoleIcon = option.icon;
                    const selected = role === option.value;

                    return (
                      <button
                        key={option.value}
                        type="button"
                        role="radio"
                        aria-checked={selected}
                        data-testid={`role-${option.value}`}
                        onClick={() => {
                          setRole(option.value);
                          setSaveError("");
                        }}
                        className={`w-full min-h-[76px] rounded-2xl border-2 p-3 flex items-center gap-3 text-left transition-all ${
                          selected
                            ? "border-primary bg-primary/5 shadow-sm"
                            : "border-border bg-card hover:border-primary/40"
                        }`}
                      >
                        <span className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                          selected ? "bg-primary text-white" : "bg-primary/10 text-primary"
                        }`}>
                          <RoleIcon size={22} strokeWidth={2} />
                        </span>
                        <span className="flex-1 min-w-0">
                          <span className="block text-sm font-extrabold text-foreground">{option.label}</span>
                          <span className="block text-xs font-medium text-muted-foreground mt-0.5">{option.description}</span>
                        </span>
                        <span className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                          selected ? "bg-primary text-white" : "border-2 border-border"
                        }`}>
                          {selected && <Check size={14} strokeWidth={3} />}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <label htmlFor="reader-name" className="block text-sm font-extrabold text-foreground mb-2">
                  {role === "adult"
                    ? "Nombre de la niña o el niño"
                    : role === "child"
                      ? "Tu nombre"
                      : "Nombre de quien va a leer"}
                </label>
                <input
                  id="reader-name"
                  data-testid="input-reader-name"
                  type="text"
                  autoComplete="given-name"
                  maxLength={32}
                  required
                  value={name}
                  onChange={(event) => {
                    setName(event.target.value);
                    setSaveError("");
                  }}
                  aria-describedby="reader-name-hint"
                  placeholder={role === "child" ? "Escribe tu nombre" : "Por ejemplo, Sofía"}
                  className="w-full rounded-2xl border-2 border-border bg-card px-4 py-3.5 text-base font-bold text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary"
                />
                <p id="reader-name-hint" className="text-xs font-medium text-muted-foreground mt-2">
                  Lo usaremos para personalizar el saludo y las actividades.
                </p>
                {saveError && (
                  <p role="alert" className="text-sm font-semibold text-destructive mt-2">
                    {saveError}
                  </p>
                )}
              </div>
            ) : (
              <>
                <div className={`w-full rounded-3xl ${currentStep.bg} flex items-center justify-center mb-8`} style={{ height: 280 }}>
                  <div className={`w-28 h-28 rounded-3xl bg-gradient-to-br ${currentStep.color} flex items-center justify-center shadow-xl`}>
                    <currentStep.icon size={52} className="text-white" strokeWidth={1.8} />
                  </div>
                </div>

                <h2 className="text-3xl font-black text-foreground mb-4 leading-tight">{currentStep.title}</h2>
                <p className="text-muted-foreground text-base font-medium leading-relaxed">{currentStep.desc}</p>
              </>
            )}
          </motion.div>
        </AnimatePresence>

        <motion.button
          type="submit"
          data-testid="button-next-onboarding"
          whileTap={{ scale: 0.95 }}
          disabled={isProfileStep && (!role || !name.trim())}
          className="mt-8 w-full py-4 rounded-2xl font-black text-lg text-white shadow-lg flex items-center justify-center gap-2 disabled:cursor-not-allowed disabled:opacity-50"
          style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(280,70%,58%))" }}
        >
          {isProfileStep ? (
            <>Continuar <ChevronRight size={22} /></>
          ) : step < totalSteps - 1 ? (
            <>Siguiente <ChevronRight size={22} /></>
          ) : (
            "Empezar"
          )}
        </motion.button>
      </form>
    </div>
  );
}
