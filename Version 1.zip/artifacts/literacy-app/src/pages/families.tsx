import { useState } from "react";
import { motion } from "framer-motion";
import { BookOpen, Clock, Activity, CheckSquare, Square, BarChart2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";

const tips = [
  { icon: BookOpen, title: "Lee en voz alta juntos", desc: "15 minutos al dia hace una gran diferencia. Lee con expresion y haz preguntas sobre la historia.", color: "text-violet-500", bg: "bg-violet-50" },
  { icon: Clock, title: "Establece un horario", desc: "Un momento fijo para la lectura (antes de dormir funciona muy bien) crea el habito naturalmente.", color: "text-orange-500", bg: "bg-orange-50" },
  { icon: Activity, title: "Variedad de formatos", desc: "Alterna entre cuentos, audiolibros y videos educativos para mantener el interes y reforzar el aprendizaje.", color: "text-emerald-500", bg: "bg-emerald-50" },
];

const habits = [
  "Leer al menos 15 minutos por dia",
  "Visitar la biblioteca semanal",
  "Preguntar que aprendio hoy",
  "Limitar pantallas a 1h por dia",
  "Contar cuentos antes de dormir",
  "Cantar canciones infantiles",
];

const weekData = [
  { day: "Lun", min: 18 },
  { day: "Mar", min: 25 },
  { day: "Mie", min: 10 },
  { day: "Jue", min: 30 },
  { day: "Vie", min: 22 },
  { day: "Sab", min: 35 },
  { day: "Dom", min: 15 },
];

export default function Families() {
  const [checked, setChecked] = useState<number[]>([0, 3]);

  const toggleCheck = (i: number) => {
    setChecked((c) => c.includes(i) ? c.filter((x) => x !== i) : [...c, i]);
  };

  return (
    <div className="px-5 pt-10 pb-4">
      <div className="mb-6">
        <h1 className="text-2xl font-black text-foreground">Guia para familias</h1>
        <p className="text-muted-foreground text-sm font-medium">Apoya el aprendizaje de tu nino</p>
      </div>

      <div className="bg-card border border-border rounded-3xl p-5 mb-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <BarChart2 size={18} className="text-primary" />
          <h2 className="font-black text-foreground text-base">Dashboard semanal</h2>
        </div>
        <div className="grid grid-cols-3 gap-3 mb-5">
          {[
            { label: "Min lectura", value: "155", color: "text-violet-600" },
            { label: "Actividades", value: "12", color: "text-orange-500" },
            { label: "Dias activos", value: "6/7", color: "text-emerald-600" },
          ].map((s) => (
            <div key={s.label} className="bg-muted/50 rounded-2xl p-3 text-center">
              <p className={`text-xl font-black ${s.color}`}>{s.value}</p>
              <p className="text-muted-foreground text-xs font-semibold mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
        <ResponsiveContainer width="100%" height={110}>
          <BarChart data={weekData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
            <XAxis dataKey="day" tick={{ fontSize: 10, fontWeight: 700, fill: "hsl(262,30%,40%)" }} axisLine={false} tickLine={false} />
            <YAxis hide />
            <Tooltip
              contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 4px 12px rgba(0,0,0,0.1)", fontSize: 12, fontWeight: 700 }}
              formatter={(v: number) => [`${v} min`, "Lectura"]}
            />
            <Bar dataKey="min" fill="hsl(262,75%,62%)" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <h2 className="font-black text-foreground text-base mb-3">Consejos practicos</h2>
      <div className="space-y-3 mb-6">
        {tips.map((tip, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-card border border-border rounded-3xl p-4 shadow-sm flex gap-4"
          >
            <div className={`w-11 h-11 ${tip.bg} rounded-2xl flex items-center justify-center flex-shrink-0`}>
              <tip.icon size={20} className={tip.color} strokeWidth={2} />
            </div>
            <div>
              <p className="font-black text-foreground text-sm mb-0.5">{tip.title}</p>
              <p className="text-muted-foreground text-xs font-medium leading-relaxed">{tip.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-card border border-border rounded-3xl p-5 mb-6 shadow-sm">
        <h2 className="font-black text-foreground text-base mb-1">Tiempo recomendado</h2>
        <p className="text-muted-foreground text-xs font-medium mb-4">Segun la edad del nino</p>
        <div className="space-y-2">
          {[
            { age: "0-2 anos", time: "5-10 min/dia", pct: 25 },
            { age: "3-5 anos", time: "15-20 min/dia", pct: 55 },
            { age: "6-7 anos", time: "20-30 min/dia", pct: 80 },
          ].map((r) => (
            <div key={r.age}>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-foreground">{r.age}</span>
                <span className="text-muted-foreground">{r.time}</span>
              </div>
              <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full" style={{ width: `${r.pct}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-card border border-border rounded-3xl p-5 shadow-sm">
        <h2 className="font-black text-foreground text-base mb-4">Habitos diarios</h2>
        <div className="space-y-3">
          {habits.map((h, i) => (
            <button
              key={i}
              data-testid={`checkbox-habit-${i}`}
              onClick={() => toggleCheck(i)}
              className="flex items-center gap-3 w-full text-left"
            >
              {checked.includes(i)
                ? <CheckSquare size={20} className="text-primary flex-shrink-0" strokeWidth={2} />
                : <Square size={20} className="text-muted-foreground flex-shrink-0" strokeWidth={1.5} />
              }
              <span className={`text-sm font-semibold ${checked.includes(i) ? "text-foreground line-through text-muted-foreground" : "text-foreground"}`}>{h}</span>
            </button>
          ))}
        </div>
        <div className="mt-4 bg-muted/50 rounded-2xl p-3 text-center">
          <p className="text-primary font-black text-sm">{checked.length}/{habits.length} habitos completados</p>
        </div>
      </div>
    </div>
  );
}
