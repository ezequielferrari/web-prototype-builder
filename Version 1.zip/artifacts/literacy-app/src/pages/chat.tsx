import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Mic } from "lucide-react";

interface Message {
  id: number;
  text: string;
  from: "lumi" | "user";
}

const initialMessages: Message[] = [
  { id: 1, text: "Hola! Soy Lumi, tu amigo virtual! Estoy aqui para jugar y aprender contigo. De que queres hablar hoy?", from: "lumi" },
];

const quickReplies = [
  "Cual es tu animal favorito?",
  "Queremos inventar una historia?",
  "Que libros te gustan?",
  "Enseneme una palabra nueva",
];

const lumiResponses: Record<string, string> = {
  "Cual es tu animal favorito?": "Mi animal favorito es el delfin! Son muy listos y juguetones. Pueden saltar muy alto en el agua. Y el tuyo, cual es?",
  "Queremos inventar una historia?": "Me encanta inventar historias! Habia una vez una princesa que vivia en un castillo de nubes... Que crees que pasaba despues?",
  "Que libros te gustan?": "Me encantan los libros de aventuras y de ciencia! El principito es uno de mis favoritos. Habla de la amistad y de ver el mundo con ojos de nino. Has leido alguno?",
  "Enseneme una palabra nueva": "Hoy te enseno: ESTUPENDO! Significa algo muy muy bueno. Por ejemplo: Tu lectura de hoy estuvo estupenda! Ahora usala en una oracion.",
};

const defaultResponse = "Que interesante lo que me contas! Cuentame mas, me encanta escucharte. Eres muy inteligente!";

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { id: Date.now(), text, from: "user" };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      const response = lumiResponses[text] || defaultResponse;
      setMessages((m) => [...m, { id: Date.now() + 1, text: response, from: "lumi" }]);
      setTyping(false);
    }, 1500);
  };

  return (
    <div className="flex flex-col h-full max-h-screen">
      <div className="px-5 pt-10 pb-4 border-b border-border bg-card">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-white text-xl shadow-md"
              style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(340,80%,70%))" }}>
              L
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-background" />
          </div>
          <div>
            <p className="font-black text-foreground text-base">Lumi</p>
            <p className="text-emerald-500 text-xs font-bold">En linea ahora</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              data-testid={`message-${msg.from}-${msg.id}`}
              initial={{ opacity: 0, y: 12, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ type: "spring", bounce: 0.4 }}
              className={`flex ${msg.from === "user" ? "justify-end" : "justify-start"} items-end gap-2`}
            >
              {msg.from === "lumi" && (
                <div className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-sm font-black flex-shrink-0 mb-1"
                  style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(340,80%,70%))" }}>
                  L
                </div>
              )}
              <div
                className={`max-w-[75%] px-4 py-3 rounded-2xl text-sm font-semibold leading-relaxed ${
                  msg.from === "user"
                    ? "text-white rounded-br-sm"
                    : "bg-card border border-border text-foreground rounded-bl-sm"
                }`}
                style={msg.from === "user" ? { background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(280,65%,55%))" } : {}}
              >
                {msg.text}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {typing && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex items-end gap-2">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-sm font-black flex-shrink-0"
              style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(340,80%,70%))" }}>
              L
            </div>
            <div className="bg-card border border-border px-4 py-3 rounded-2xl rounded-bl-sm flex gap-1.5 items-center">
              {[0, 1, 2].map((i) => (
                <motion.div key={i} className="w-2 h-2 bg-primary/40 rounded-full"
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                />
              ))}
            </div>
          </motion.div>
        )}
        <div ref={bottomRef} />
      </div>

      <div className="px-4 py-3 border-t border-border bg-card">
        <div className="flex gap-2 overflow-x-auto mb-3 pb-1">
          {quickReplies.map((r) => (
            <button
              key={r}
              data-testid={`button-quick-reply-${r}`}
              onClick={() => sendMessage(r)}
              className="flex-shrink-0 bg-primary/10 text-primary text-xs font-bold px-3 py-2 rounded-full border border-primary/20 whitespace-nowrap"
            >
              {r}
            </button>
          ))}
        </div>
        <div className="flex gap-2 items-center">
          <button data-testid="button-voice-input" className="w-10 h-10 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
            <Mic size={18} className="text-muted-foreground" />
          </button>
          <input
            data-testid="input-chat-message"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage(input)}
            placeholder="Escribi un mensaje..."
            className="flex-1 bg-muted rounded-2xl px-4 py-2.5 text-sm font-semibold text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground"
          />
          <motion.button
            data-testid="button-send-message"
            whileTap={{ scale: 0.9 }}
            onClick={() => sendMessage(input)}
            className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 shadow-md"
            style={{ background: "linear-gradient(135deg, hsl(262,75%,62%), hsl(280,65%,55%))" }}
          >
            <Send size={16} className="text-white" />
          </motion.button>
        </div>
      </div>
    </div>
  );
}
