import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AnimatePresence } from "framer-motion";
import NotFound from "@/pages/not-found";
import Splash from "@/pages/splash";
import Onboarding from "@/pages/onboarding";
import Home from "@/pages/home";
import Library from "@/pages/library";
import Reading from "@/pages/reading";
import Families from "@/pages/families";
import Stories from "@/pages/stories";
import Chat from "@/pages/chat";
import Profile from "@/pages/profile";
import Layout from "@/components/layout/mobile-container";

const queryClient = new QueryClient();

function Router() {
  return (
    <AnimatePresence mode="wait">
      <Switch>
        <Route path="/" component={Splash} />
        <Route path="/splash" component={Splash} />
        <Route path="/onboarding" component={Onboarding} />
        
        {/* Main app routes wrapped in mobile layout with bottom nav */}
        <Route path="/home">
          <Layout><Home /></Layout>
        </Route>
        <Route path="/library">
          <Layout><Library /></Layout>
        </Route>
        <Route path="/reading">
          <Layout><Reading /></Layout>
        </Route>
        <Route path="/families">
          <Layout><Families /></Layout>
        </Route>
        <Route path="/stories">
          <Layout><Stories /></Layout>
        </Route>
        <Route path="/chat">
          <Layout><Chat /></Layout>
        </Route>
        <Route path="/profile">
          <Layout><Profile /></Layout>
        </Route>
        
        <Route component={NotFound} />
      </Switch>
    </AnimatePresence>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
