export type PankaRole = "adult" | "child";

export interface PankaProfile {
  name: string;
  role: PankaRole;
}

const PROFILE_STORAGE_KEY = "panka.reader-profile.v1";

export function readPankaProfile(): PankaProfile | null {
  try {
    const stored = window.localStorage.getItem(PROFILE_STORAGE_KEY);
    if (!stored) return null;

    const value: unknown = JSON.parse(stored);
    if (typeof value !== "object" || value === null) return null;

    const profile = value as Record<string, unknown>;
    if (
      typeof profile.name !== "string" ||
      !profile.name.trim() ||
      (profile.role !== "adult" && profile.role !== "child")
    ) {
      return null;
    }

    return { name: profile.name.trim(), role: profile.role };
  } catch {
    return null;
  }
}

export function savePankaProfile(profile: PankaProfile): void {
  window.localStorage.setItem(
    PROFILE_STORAGE_KEY,
    JSON.stringify({ ...profile, name: profile.name.trim() }),
  );
}