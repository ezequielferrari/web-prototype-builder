import { Story } from "../context/AppContext";

export const ALL_STORIES: Story[] = [
  { id: "s1", title: "El Osito Valiente", author: "Ana M.", ageRange: "0-2", level: "inicial", coverColor: "bg-gradient-to-br from-orange-400 to-orange-500", coverEmoji: "🐻" },
  { id: "s2", title: "La Princesa del Bosque", author: "Luis G.", ageRange: "3-5", level: "intermedio", coverColor: "bg-gradient-to-br from-pink-400 to-rose-500", coverEmoji: "👸" },
  { id: "s3", title: "Viaje al Espacio", author: "Carlos T.", ageRange: "6-7", level: "avanzado", coverColor: "bg-gradient-to-br from-indigo-500 to-purple-600", coverEmoji: "🚀" },
  { id: "s4", title: "El Dragón Amigable", author: "Sofia R.", ageRange: "3-5", level: "intermedio", coverColor: "bg-gradient-to-br from-green-400 to-emerald-500", coverEmoji: "🐲" },
  { id: "s5", title: "La Tortuga Curiosa", author: "Elena V.", ageRange: "0-2", level: "inicial", coverColor: "bg-gradient-to-br from-teal-400 to-teal-500", coverEmoji: "🐢" },
  { id: "s6", title: "Colores del Mundo", author: "Pedro L.", ageRange: "3-5", level: "inicial", coverColor: "bg-gradient-to-br from-yellow-400 to-orange-500", coverEmoji: "🌈" },
  { id: "s7", title: "El Robot Soñador", author: "Marta K.", ageRange: "6-7", level: "avanzado", coverColor: "bg-gradient-to-br from-blue-400 to-cyan-500", coverEmoji: "🤖" },
  { id: "s8", title: "Las Estrellas de Mar", author: "Julia P.", ageRange: "0-2", level: "inicial", coverColor: "bg-gradient-to-br from-cyan-400 to-blue-500", coverEmoji: "⭐" },
];

export const PHRASES = [
  "El sol brilla alto.",
  "La luna nos sonríe.",
  "El gato corre rápido.",
  "Me gusta mucho leer.",
  "Los pajaritos cantan hoy.",
  "Un día lleno de luz.",
  "Saltamos en el parque.",
  "El oso come miel.",
  "Las flores son rojas.",
  "La mariposa vuela lejos."
];

export const ACTIVITIES = [
  { id: "a1", title: "Dibuja un personaje", desc: "Dibuja un personaje del cuento que más te gustó.", type: "photo" },
  { id: "a2", title: "Lee una historia", desc: "Lee una historia a un familiar y grábate.", type: "audio" },
  { id: "a3", title: "Busca objetos", desc: "Busca objetos que empiecen con una letra.", type: "text_photo" },
  { id: "a4", title: "Inventa una historia", desc: "Inventa una historia oral y grábate.", type: "audio" }
];
