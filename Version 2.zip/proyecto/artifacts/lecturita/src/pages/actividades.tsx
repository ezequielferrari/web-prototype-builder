import { useState } from "react";
import { BottomNav } from "../components/BottomNav";
import { ACTIVITIES } from "../data/seed";
import { useAppContext } from "../context/AppContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import confetti from "canvas-confetti";
import { Upload, Mic, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Actividades() {
  const { state, markActivityComplete } = useAppContext();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  const handleComplete = (id: string) => {
    setUploading(true);
    setTimeout(() => {
      setUploading(false);
      markActivityComplete(id);
      setActiveId(null);
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    }, 1500);
  };

  return (
    <div className="min-h-[100dvh] bg-background pb-24">
      <div className="p-6 pt-12 max-w-lg mx-auto">
        <h1 className="text-2xl font-bold mb-2 text-center text-primary">Actividades Analógicas</h1>
        <p className="text-center text-muted-foreground mb-8">¡Hora de jugar fuera de la pantalla!</p>

        <div className="grid gap-4">
          {ACTIVITIES.map((act) => {
            const isCompleted = state.completedActivities.includes(act.id);
            const isActive = activeId === act.id;

            return (
              <Card 
                key={act.id} 
                className={`overflow-hidden rounded-3xl transition-all shadow-sm border-2 ${isCompleted ? 'border-green-400 bg-green-50' : 'border-transparent bg-white'}`}
              >
                <CardContent className="p-0">
                  <div 
                    className="p-6 cursor-pointer flex justify-between items-center"
                    onClick={() => !isCompleted && setActiveId(isActive ? null : act.id)}
                  >
                    <div>
                      <h3 className="font-bold text-lg">{act.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{act.desc}</p>
                    </div>
                    {isCompleted && <CheckCircle className="w-8 h-8 text-green-500" />}
                  </div>

                  <AnimatePresence>
                    {isActive && !isCompleted && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }} 
                        animate={{ height: 'auto', opacity: 1 }} 
                        exit={{ height: 0, opacity: 0 }}
                        className="px-6 pb-6"
                      >
                        <div className="border-t pt-4 flex flex-col gap-4">
                          {act.type.includes('photo') && (
                            <div className="border-2 border-dashed border-muted-foreground/30 rounded-2xl p-8 flex flex-col items-center justify-center text-muted-foreground bg-slate-50">
                              <Upload className="w-8 h-8 mb-2 opacity-50" />
                              <span className="text-sm font-bold">Subir foto de tu dibujo</span>
                            </div>
                          )}
                          {act.type.includes('text') && (
                            <Input placeholder="Escribe aquí..." className="h-12 rounded-xl" />
                          )}
                          {act.type.includes('audio') && (
                            <Button variant="secondary" className="h-14 rounded-xl flex gap-2 w-full text-lg">
                              <Mic className="w-5 h-5" /> Grabar audio
                            </Button>
                          )}
                          
                          <Button 
                            className="w-full h-14 rounded-full text-lg mt-2" 
                            onClick={() => handleComplete(act.id)}
                            disabled={uploading}
                          >
                            {uploading ? "Subiendo..." : "¡Terminé!"}
                          </Button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
