import { useState } from "react";
import { BottomNav } from "../components/BottomNav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MascotCharacter } from "../components/MascotCharacter";
import { motion, AnimatePresence } from "framer-motion";

export default function Crear() {
  const [step, setStep] = useState(0); // 0: intro, 1: hero, 2: setting, 3: result
  const [hero, setHero] = useState<any>(null);
  const [setting, setSetting] = useState<any>(null);
  
  const heroes = [
    { id: 1, name: "León", emoji: "🦁", color: "from-amber-300 to-orange-400" },
    { id: 2, name: "Unicornio", emoji: "🦄", color: "from-fuchsia-300 to-pink-400" },
    { id: 3, name: "Dino", emoji: "🦖", color: "from-lime-300 to-green-400" },
    { id: 4, name: "Robot", emoji: "🤖", color: "from-cyan-300 to-blue-400" },
  ];

  const settings = [
    { id: 1, name: "Bosque", emoji: "🌲", color: "from-emerald-300 to-green-500" },
    { id: 2, name: "Espacio", emoji: "🌌", color: "from-indigo-400 to-purple-600" },
    { id: 3, name: "Castillo", emoji: "🏰", color: "from-slate-300 to-gray-500" },
    { id: 4, name: "Playa", emoji: "🏖️", color: "from-yellow-200 to-amber-400" },
  ];

  const handleCreate = () => setStep(1);

  return (
    <div className="min-h-[100dvh] bg-background pb-24 flex flex-col">
      <div className="p-6 pt-12 flex-1 flex flex-col w-full max-w-lg mx-auto">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div key="step0" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 flex flex-col items-center justify-center text-center gap-6">
              <MascotCharacter size="lg" />
              <div>
                <h1 className="text-3xl font-bold text-primary mb-2">Crea tu Cuento</h1>
                <p className="text-muted-foreground text-lg">Inventa historias mágicas eligiendo a los personajes y lugares.</p>
              </div>
              <Button size="lg" className="w-full mt-4 h-16 rounded-full text-xl" onClick={handleCreate}>
                ¡Crear ahora!
              </Button>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div key="step1" initial={{ x: 50, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -50, opacity: 0 }} className="flex flex-col gap-6">
              <h2 className="text-2xl font-bold text-center">Elige un personaje</h2>
              <div className="grid grid-cols-2 gap-4">
                {heroes.map(h => (
                  <Card 
                    key={h.id} 
                    className="cursor-pointer border-none shadow-sm hover:scale-105 transition-transform overflow-hidden"
                    onClick={() => { setHero(h); setStep(2); }}
                  >
                    <CardContent className={`p-8 flex flex-col items-center justify-center gap-3 bg-gradient-to-br ${h.color} text-white`}>
                      <span className="text-6xl">{h.emoji}</span>
                      <span className="font-bold text-lg">{h.name}</span>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="step2" initial={{ x: 50, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -50, opacity: 0 }} className="flex flex-col gap-6">
              <h2 className="text-2xl font-bold text-center">¿Dónde están?</h2>
              <div className="grid grid-cols-2 gap-4">
                {settings.map(s => (
                  <Card 
                    key={s.id} 
                    className="cursor-pointer border-none shadow-sm hover:scale-105 transition-transform overflow-hidden"
                    onClick={() => { setSetting(s); setStep(3); }}
                  >
                    <CardContent className={`p-8 flex flex-col items-center justify-center gap-3 bg-gradient-to-br ${s.color} text-white`}>
                      <span className="text-6xl">{s.emoji}</span>
                      <span className="font-bold text-lg">{s.name}</span>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="step3" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex flex-col gap-6 items-center">
              <h2 className="text-3xl font-extrabold text-primary text-center">¡Tu Cuento está Listo!</h2>
              
              <Card className="w-full border-none shadow-md overflow-hidden bg-white">
                <div className={`h-40 bg-gradient-to-br ${setting.color} flex items-center justify-center text-7xl relative`}>
                  {setting.emoji}
                  <div className={`absolute bottom-0 translate-y-1/2 w-24 h-24 rounded-full bg-gradient-to-br ${hero.color} border-4 border-white flex items-center justify-center text-5xl shadow-sm`}>
                    {hero.emoji}
                  </div>
                </div>
                <CardContent className="p-6 pt-16 text-center">
                  <h3 className="text-2xl font-bold mb-4">El {hero.name} en el {setting.name}</h3>
                  <p className="text-muted-foreground text-lg leading-relaxed">
                    Había una vez un valiente {hero.name.toLowerCase()} que decidió explorar el {setting.name.toLowerCase()}. Fue un día lleno de aventuras y diversión.
                  </p>
                </CardContent>
              </Card>

              <div className="w-full flex gap-4 mt-4">
                <Button variant="outline" className="flex-1 h-14 rounded-full text-lg border-2" onClick={() => setStep(0)}>
                  Crear otro
                </Button>
                <Button className="flex-1 h-14 rounded-full text-lg">
                  Guardar
                </Button>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
      <BottomNav />
    </div>
  );
}
