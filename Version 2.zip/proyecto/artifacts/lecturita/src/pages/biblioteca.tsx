import { useState } from "react";
import { BottomNav } from "../components/BottomNav";
import { ALL_STORIES } from "../data/seed";
import { useAppContext } from "../context/AppContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Play, Headphones } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Biblioteca() {
  const { state, toggleFavorite } = useAppContext();
  const [filterAge, setFilterAge] = useState<string>("Todos");
  const [readingStory, setReadingStory] = useState<any>(null);

  const filtered = ALL_STORIES.filter(s => filterAge === "Todos" || s.ageRange === filterAge);

  return (
    <div className="min-h-[100dvh] bg-background pb-24 relative">
      <div className="p-6 pt-12">
        <h1 className="text-3xl font-extrabold mb-6 text-primary">Biblioteca</h1>

        <div className="flex gap-2 overflow-x-auto no-scrollbar mb-6 pb-2">
          {["Todos", "0-2", "3-5", "6-7"].map((age) => (
            <Button
              key={age}
              variant={filterAge === age ? "default" : "outline"}
              className="rounded-full shrink-0 h-10 px-6 font-bold"
              onClick={() => setFilterAge(age)}
            >
              {age === "Todos" ? age : `${age} años`}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-4">
          {filtered.map(story => {
            const isFav = state.favorites.includes(story.id);
            return (
              <Card key={story.id} className="border-none shadow-sm rounded-3xl overflow-hidden group">
                <div className={`h-32 ${story.coverColor} flex items-center justify-center text-5xl relative`}>
                  {story.coverEmoji}
                  <button 
                    className="absolute top-2 right-2 p-2 bg-white/30 rounded-full backdrop-blur-sm"
                    onClick={() => toggleFavorite(story.id)}
                  >
                    <Heart className={`w-5 h-5 ${isFav ? 'fill-red-500 text-red-500' : 'text-white'}`} />
                  </button>
                </div>
                <CardContent className="p-4 bg-white">
                  <h3 className="font-bold leading-tight mb-1">{story.title}</h3>
                  <div className="flex justify-between items-center mt-3">
                    <Button size="icon" variant="secondary" className="w-10 h-10 rounded-full bg-primary/10 text-primary hover:bg-primary/20" onClick={() => setReadingStory(story)}>
                      <Play className="w-4 h-4 ml-1" />
                    </Button>
                    <Button size="icon" variant="secondary" className="w-10 h-10 rounded-full bg-secondary/10 text-secondary hover:bg-secondary/20">
                      <Headphones className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <AnimatePresence>
        {readingStory && (
          <motion.div 
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-50 bg-white flex flex-col"
          >
            <div className={`h-48 ${readingStory.coverColor} flex flex-col items-center justify-center text-7xl relative`}>
              <button 
                className="absolute top-12 left-6 bg-black/20 text-white w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-sm"
                onClick={() => setReadingStory(null)}
              >
                ✕
              </button>
              {readingStory.coverEmoji}
            </div>
            <div className="flex-1 overflow-y-auto p-8 flex flex-col gap-6 text-xl leading-relaxed text-foreground bg-amber-50/50">
              <h2 className="text-3xl font-extrabold text-primary text-center mb-4">{readingStory.title}</h2>
              <p>Había una vez, en un lugar muy lejano, {readingStory.title.toLowerCase()} que le encantaba explorar.</p>
              <p>Un día, mientras caminaba por el bosque, encontró un pequeño tesoro brillante escondido bajo unas hojas.</p>
              <p>Decidió llevarlo a casa para compartirlo con todos sus amigos, y vivieron felices para siempre.</p>
              
              <div className="mt-auto pt-8 border-t border-amber-200">
                <h4 className="font-bold text-lg mb-4 text-center">¿Qué encontró en el bosque?</h4>
                <div className="flex flex-col gap-3">
                   {["Una manzana", "Un tesoro", "Una flor"].map((ans, i) => (
                     <Button key={i} variant="outline" className="h-14 rounded-2xl justify-start px-6 bg-white border-2">
                       {ans}
                     </Button>
                   ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <BottomNav />
    </div>
  );
}
