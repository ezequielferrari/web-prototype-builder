import { useState, useRef, useEffect } from "react";
import { BottomNav } from "../components/BottomNav";
import { MascotCharacter } from "../components/MascotCharacter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Mic } from "lucide-react";
import { motion } from "framer-motion";

interface Msg {
  id: string;
  sender: "lectu" | "user";
  text: string;
}

export default function Chat() {
  const [messages, setMessages] = useState<Msg[]>([
    { id: "1", sender: "lectu", text: "¡Hola! Soy Lectu, tu ayudante mágico. 🦉" },
    { id: "2", sender: "lectu", text: "¿Qué letra te gustaría practicar hoy?" }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    const newMsg: Msg = { id: Date.now().toString(), sender: "user", text: input };
    setMessages(prev => [...prev, newMsg]);
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: "lectu",
        text: `¡Qué bien! "${newMsg.text}" es una excelente elección. ¡Vamos a buscar cuentos divertidos! 🌟`
      }]);
    }, 1500);
  };

  return (
    <div className="h-[100dvh] bg-slate-50 flex flex-col pb-20">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4 pt-10 flex items-center gap-4 rounded-b-3xl shadow-sm z-10 relative">
        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center p-1">
          <MascotCharacter size="sm" />
        </div>
        <div>
          <h2 className="font-bold text-lg">Lectu</h2>
          <p className="text-xs opacity-90">Siempre aquí para ayudarte</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
        {messages.map((m) => (
          <motion.div 
            key={m.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[80%] p-4 rounded-3xl ${
              m.sender === 'user' 
                ? 'bg-secondary text-white rounded-br-none' 
                : 'bg-white border shadow-sm text-foreground rounded-bl-none'
            }`}>
              <p className="text-base font-medium">{m.text}</p>
            </div>
          </motion.div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white border shadow-sm p-4 rounded-3xl rounded-bl-none flex gap-1">
              <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" />
              <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce delay-75" />
              <span className="w-2 h-2 bg-gray-300 rounded-full animate-bounce delay-150" />
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-4 bg-white border-t flex gap-2 items-center">
        <Button variant="secondary" size="icon" className="h-12 w-12 rounded-full shrink-0">
          <Mic className="w-5 h-5" />
        </Button>
        <Input 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Escribe un mensaje..."
          className="h-12 rounded-full border-2 bg-slate-50 px-4"
        />
        <Button onClick={handleSend} size="icon" className="h-12 w-12 rounded-full shrink-0">
          <Send className="w-5 h-5" />
        </Button>
      </div>

      <BottomNav />
    </div>
  );
}
