import { useState } from "react";
import { BottomNav } from "../components/BottomNav";
import { useAppContext } from "../context/AppContext";
import { MascotCharacter } from "../components/MascotCharacter";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import confetti from "canvas-confetti";
import { motion } from "framer-motion";

export default function Metacognicion() {
  const { state, addReflection } = useAppContext();
  const [text, setText] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (!text.trim()) return;
    addReflection(text);
    setText("");
    setSaved(true);
    confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    setTimeout(() => setSaved(false), 3000);
  };

  const toggleRecord = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      setTimeout(() => {
        setText(prev => prev + " Hoy aprendí muchas palabras nuevas con la letra S. ");
        setIsRecording(false);
      }, 3000);
    }
  };

  return (
    <div className="min-h-[100dvh] bg-background pb-24">
      <div className="p-6 pt-12 max-w-lg mx-auto flex flex-col gap-6">
        <div className="text-center">
          <MascotCharacter size="md" className="mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-primary">¿Qué aprendiste hoy?</h1>
          <p className="text-muted-foreground mt-2">Cuéntame lo que más te gustó de hoy.</p>
        </div>

        <div className="relative">
          <Textarea 
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Hoy aprendí..."
            className="min-h-[150px] rounded-3xl p-6 text-lg border-2 resize-none bg-white shadow-sm"
          />
          <Button 
            size="icon" 
            variant="secondary"
            className={`absolute bottom-4 right-4 h-12 w-12 rounded-full shadow-md transition-all ${isRecording ? 'bg-red-500 text-white animate-pulse hover:bg-red-600' : ''}`}
            onClick={toggleRecord}
          >
            🎤
          </Button>
        </div>

        <Button 
          size="lg" 
          className="w-full h-14 rounded-full text-xl" 
          onClick={handleSave}
          disabled={!text.trim() || saved}
        >
          {saved ? "¡Guardado!" : "Guardar reflexión"}
        </Button>

        {state.reflections.length > 0 && (
          <div className="mt-8">
            <h2 className="text-xl font-bold mb-4">Tus recuerdos</h2>
            <div className="flex flex-col gap-3">
              {state.reflections.map((ref, i) => (
                <Card key={i} className="p-4 rounded-2xl shadow-sm border-none bg-white">
                  <p className="text-muted-foreground text-sm mb-1">
                    {new Date(ref.date).toLocaleDateString()}
                  </p>
                  <p className="font-medium">{ref.text}</p>
                </Card>
              ))}
            </div>
          </div>
        )}

      </div>
      <BottomNav />
    </div>
  );
}
