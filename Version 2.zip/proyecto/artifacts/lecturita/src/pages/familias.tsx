import { useState } from "react";
import { BottomNav } from "../components/BottomNav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function Familias() {
  const [habits, setHabits] = useState({ h1: true, h2: false, h3: false });

  const chartData = [
    { day: "L", v: 20 },
    { day: "M", v: 35 },
    { day: "X", v: 15 },
    { day: "J", v: 40 },
    { day: "V", v: 25 },
    { day: "S", v: 50 },
    { day: "D", v: 60 },
  ];

  return (
    <div className="min-h-[100dvh] bg-background pb-24">
      <div className="p-6 pt-12 max-w-lg mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-extrabold text-primary mb-2">Guía Familias</h1>
          <p className="text-muted-foreground">Monitorea el progreso y descubre tips.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="border-none shadow-sm rounded-3xl bg-gradient-to-br from-blue-50 to-cyan-50">
            <CardContent className="p-5">
              <p className="text-sm font-bold text-muted-foreground mb-1">Nivel actual</p>
              <p className="text-2xl font-extrabold text-secondary">Intermedio</p>
            </CardContent>
          </Card>
          <Card className="border-none shadow-sm rounded-3xl bg-gradient-to-br from-accent/10 to-[#fdb416]/15">
            <CardContent className="p-5">
              <p className="text-sm font-bold text-muted-foreground mb-1">Actividades</p>
              <p className="text-2xl font-extrabold text-primary">12 completadas</p>
            </CardContent>
          </Card>
        </div>

        {/* Chart */}
        <Card className="border-none shadow-sm rounded-3xl p-6 bg-white">
          <h3 className="font-bold text-lg mb-4">Tiempo de lectura (min)</h3>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <XAxis dataKey="day" axisLine={false} tickLine={false} />
                <Tooltip cursor={{fill: '#f4f4f5'}} contentStyle={{borderRadius: '1rem', border: 'none'}} />
                <Bar dataKey="v" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Habits Checklist */}
        <div>
          <h3 className="font-bold text-lg mb-4">Hábitos saludables</h3>
          <Card className="border-none shadow-sm rounded-3xl bg-white">
            <CardContent className="p-2">
              <div className="flex items-center space-x-3 p-4 border-b">
                <Checkbox id="h1" checked={habits.h1} onCheckedChange={(c) => setHabits(s => ({...s, h1: !!c}))} className="h-6 w-6 rounded-full" />
                <label htmlFor="h1" className="text-base font-medium leading-none cursor-pointer">Leer 15 mins antes de dormir</label>
              </div>
              <div className="flex items-center space-x-3 p-4 border-b">
                <Checkbox id="h2" checked={habits.h2} onCheckedChange={(c) => setHabits(s => ({...s, h2: !!c}))} className="h-6 w-6 rounded-full" />
                <label htmlFor="h2" className="text-base font-medium leading-none cursor-pointer">Preguntar "¿Qué aprendiste hoy?"</label>
              </div>
              <div className="flex items-center space-x-3 p-4">
                <Checkbox id="h3" checked={habits.h3} onCheckedChange={(c) => setHabits(s => ({...s, h3: !!c}))} className="h-6 w-6 rounded-full" />
                <label htmlFor="h3" className="text-base font-medium leading-none cursor-pointer">Jugar a buscar letras en la calle</label>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tips Carousel Fake */}
        <div>
          <h3 className="font-bold text-lg mb-4">Tips para casa</h3>
          <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
            <Card className="min-w-[250px] border-none shadow-sm rounded-3xl bg-gradient-to-br from-green-50 to-emerald-50 shrink-0">
              <CardContent className="p-6">
                <div className="text-3xl mb-2">📚</div>
                <h4 className="font-bold mb-2">Rincón de lectura</h4>
                <p className="text-sm text-muted-foreground">Crea un espacio cómodo con cojines y libros a su alcance.</p>
              </CardContent>
            </Card>
            <Card className="min-w-[250px] border-none shadow-sm rounded-3xl bg-gradient-to-br from-purple-50 to-fuchsia-50 shrink-0">
              <CardContent className="p-6">
                <div className="text-3xl mb-2">🗣️</div>
                <h4 className="font-bold mb-2">Lectura en voz alta</h4>
                <p className="text-sm text-muted-foreground">Haz voces diferentes para cada personaje, ¡les encanta!</p>
              </CardContent>
            </Card>
          </div>
        </div>

      </div>
      <BottomNav />
    </div>
  );
}
