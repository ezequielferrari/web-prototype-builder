import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAppContext } from "../context/AppContext";
import { BottomNav } from "../components/BottomNav";
import { MascotCharacter } from "../components/MascotCharacter";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Star, Sparkles, Award } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const [, setLocation] = useLocation();
  const { state } = useAppContext();

  useEffect(() => {
    if (!state.profileType) {
      setLocation("/");
    }
  }, [state.profileType, setLocation]);

  const name = state.childProfile?.name || "Amigo";

  return (
    <div className="min-h-[100dvh] bg-background pb-24">
      {/* Header */}
      <div className="bg-primary pt-12 pb-6 px-6 rounded-b-[2rem] shadow-sm text-primary-foreground">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-extrabold mb-1">¡Hola, {name}!</h1>
            <p className="opacity-90 font-medium">¿Qué vamos a aprender hoy?</p>
          </div>
          <MascotCharacter size="sm" />
        </div>
        
        {/* Streak */}
        <div className="bg-white/20 rounded-2xl p-4 flex items-center justify-between backdrop-blur-sm border border-white/30">
          <div className="flex items-center gap-3">
            <div className="bg-white text-primary w-10 h-10 rounded-full flex items-center justify-center shadow-inner">
              <span className="text-xl">🔥</span>
            </div>
            <div>
              <div className="font-bold">Racha diaria</div>
              <div className="text-sm opacity-90">{state.streak} días seguidos</div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Recommended Activities */}
        <div>
          <h2 className="text-xl font-bold mb-4 text-foreground flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-accent" />
            Para ti hoy
          </h2>
          <div className="grid gap-4">
            <Link href="/lectura">
              <Card className="hover-elevate cursor-pointer border-none shadow-sm overflow-hidden bg-gradient-to-r from-accent/15 to-[#fdb416]/15">
                <CardContent className="p-0 flex">
                  <div className="w-24 bg-primary/20 flex items-center justify-center">
                    <span className="text-4xl">🎤</span>
                  </div>
                  <div className="p-4 flex-1">
                    <h3 className="font-bold text-lg mb-1">Lectura en voz alta</h3>
                    <p className="text-sm text-muted-foreground">Practica leer 3 frases</p>
                  </div>
                </CardContent>
              </Card>
            </Link>

            <Link href="/diagnostico">
              <Card className="hover-elevate cursor-pointer border-none shadow-sm overflow-hidden bg-gradient-to-r from-blue-50 to-cyan-50">
                <CardContent className="p-0 flex">
                  <div className="w-24 bg-secondary/20 flex items-center justify-center">
                    <span className="text-4xl">🧩</span>
                  </div>
                  <div className="p-4 flex-1">
                    <h3 className="font-bold text-lg mb-1">Juego de palabras</h3>
                    <p className="text-sm text-muted-foreground">Encuentra la letra escondida</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>

        {/* Badges */}
        <div>
          <div className="flex justify-between items-end mb-4">
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
              <Award className="w-5 h-5 text-primary" />
              Tus medallas
            </h2>
            <span className="text-sm text-primary font-bold">Ver todas</span>
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
            {[1, 2, 3, 4].map((i) => (
              <motion.div 
                key={i}
                whileHover={{ scale: 1.05 }}
                className="flex-shrink-0 w-20 h-20 rounded-2xl bg-white shadow-sm border border-border flex items-center justify-center text-3xl"
              >
                {i === 1 ? '🌟' : i === 2 ? '📚' : i === 3 ? '🎨' : '🔒'}
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
