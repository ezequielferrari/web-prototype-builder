import { useState } from "react";
import { BottomNav } from "../components/BottomNav";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { Progress } from "@/components/ui/progress";

export default function Diagnostico() {
  const [step, setStep] = useState(0); // 0: intro, 1: visual, 2: reading, 3: oral, 4: results
  const [selectedImage, setSelectedImage] = useState<number | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isRecording, setIsRecording] = useState(false);

  const nextStep = () => setStep((s) => s + 1);

  return (
    <div className="min-h-[100dvh] bg-background pb-24 flex flex-col">
      <div className="p-6 pt-12 flex-1 flex flex-col max-w-lg mx-auto w-full">
        <h1 className="text-2xl font-bold mb-6 text-center text-primary">Evaluación</h1>

        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div key="step0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col items-center text-center gap-6">
              <div className="w-32 h-32 bg-secondary/20 rounded-full flex items-center justify-center text-6xl">
                🎓
              </div>
              <div>
                <h2 className="text-xl font-bold mb-2">¡Vamos a jugar un poco!</h2>
                <p className="text-muted-foreground">Haremos unas actividades cortas para saber qué cuentos te gustarán más.</p>
              </div>
              <Button size="lg" className="w-full mt-4 rounded-full h-14 text-xl" onClick={nextStep}>
                Empezar
              </Button>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col gap-6">
              <div className="flex justify-between items-center text-sm font-bold text-muted-foreground">
                <span>Paso 1 de 3</span>
                <span>Visual</span>
              </div>
              <h2 className="text-2xl font-bold text-center">¿Cuál es el perro?</h2>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { id: 0, emoji: "🐱", color: "from-blue-200 to-blue-300" },
                  { id: 1, emoji: "🐶", color: "from-green-200 to-green-300" },
                  { id: 2, emoji: "🐰", color: "from-purple-200 to-purple-300" },
                  { id: 3, emoji: "🦊", color: "from-pink-200 to-pink-300" }
                ].map((item) => (
                  <Card 
                    key={item.id} 
                    className={`cursor-pointer transition-transform border-4 ${selectedImage === item.id ? 'border-primary scale-105' : 'border-transparent'}`}
                    onClick={() => { setSelectedImage(item.id); setTimeout(nextStep, 1000); }}
                  >
                    <CardContent className={`p-8 flex items-center justify-center text-6xl bg-gradient-to-br ${item.color}`}>
                      {item.emoji}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col gap-6">
               <div className="flex justify-between items-center text-sm font-bold text-muted-foreground">
                <span>Paso 2 de 3</span>
                <span>Lectura</span>
              </div>
              <Card className="bg-white border-none shadow-sm p-6 text-center">
                <p className="text-xl font-bold mb-4">El gato come pescado en el techo.</p>
              </Card>
              <h2 className="text-xl font-bold text-center">¿Dónde come el gato?</h2>
              <div className="flex flex-col gap-3">
                {["En el piso", "En el techo", "En la mesa"].map((ans, i) => (
                  <Button 
                    key={i} 
                    variant={selectedAnswer === i ? "default" : "outline"}
                    className="h-14 text-lg justify-start px-6 rounded-2xl"
                    onClick={() => { setSelectedAnswer(i); setTimeout(nextStep, 1000); }}
                  >
                    {ans}
                  </Button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col gap-6 items-center text-center">
               <div className="flex justify-between items-center text-sm font-bold text-muted-foreground w-full">
                <span>Paso 3 de 3</span>
                <span>Oral</span>
              </div>
              <h2 className="text-2xl font-bold">Lee esta palabra en voz alta</h2>
              <div className="text-5xl font-extrabold text-primary py-8">
                SOL
              </div>
              
              <Button 
                size="lg" 
                className={`w-32 h-32 rounded-full text-4xl shadow-lg transition-colors ${isRecording ? "bg-red-500 hover:bg-red-600 animate-pulse" : "bg-primary hover:bg-primary/90"}`}
                onClick={() => {
                  setIsRecording(true);
                  setTimeout(() => { setIsRecording(false); nextStep(); }, 3000);
                }}
                disabled={isRecording}
              >
                🎤
              </Button>
              <p className="text-muted-foreground mt-4">
                {isRecording ? "Escuchando..." : "Toca para grabar"}
              </p>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div key="step4" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col gap-6 items-center text-center">
               <div className="text-6xl mb-4">🌟</div>
               <h2 className="text-3xl font-extrabold text-primary">¡Terminamos!</h2>
               <div className="bg-card p-6 rounded-3xl w-full border border-border shadow-sm">
                 <p className="text-lg text-muted-foreground mb-2">Tu nivel es:</p>
                 <div className="text-2xl font-bold text-secondary mb-4">Intermedio</div>
                 <Progress value={60} className="h-4" />
               </div>
               <div className="w-full mt-4">
                 <h3 className="font-bold text-lg mb-3">Recomendaciones:</h3>
                 <ul className="text-left space-y-2 text-muted-foreground">
                   <li>✅ Cuentos cortos con imágenes</li>
                   <li>✅ Práctica de sílabas trabadas</li>
                   <li>✅ Juegos de rimas</li>
                 </ul>
               </div>
               <Button size="lg" className="w-full mt-6 rounded-full h-14 text-xl" onClick={() => window.history.back()}>
                 Volver al inicio
               </Button>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
      <BottomNav />
    </div>
  );
}
