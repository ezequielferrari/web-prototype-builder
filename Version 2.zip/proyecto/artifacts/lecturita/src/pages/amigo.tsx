import { useState, useRef, useEffect } from "react";
import { BottomNav } from "../components/BottomNav";
import { Button } from "@/components/ui/button";
import { Mic } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";

interface Msg {
  id: string;
  sender: "luna" | "user";
  text: string;
}

export default function Amigo() {
  const [messages, setMessages] = useState<Msg[]>([
    { id: "1", sender: "luna", text: "¡Hola! Soy Luna, tu amiga estrella. 🌙" },
    { id: "2", sender: "luna", text: "¿Cuál es tu animal favorito?" }
  ]);
  const [step, setStep] = useState(0); // tracks conversation depth
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleReply = (text: string) => {
    setMessages(prev => [...prev, { id: Date.now().toString(), sender: "user", text }]);
    
    setTimeout(() => {
      let nextLunaMsg = "";
      if (step === 0) {
        nextLunaMsg = `¡Los ${text.toLowerCase()} son geniales! ¿De qué color te gustan?`;
      } else if (step === 1) {
        nextLunaMsg = `¡El ${text.toLowerCase()} es un color muy bonito! Eres muy inteligente.`;
        setTimeout(() => {
          confetti({ particleCount: 100, spread: 70, origin: { y: 0.3 } });
        }, 500);
      } else {
        nextLunaMsg = "¿Quieres que te cuente un secreto del espacio?";
      }
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), sender: "luna", text: nextLunaMsg }]);
      setStep(s => s + 1);
    }, 1500);
  };

  return (
    <div className="h-[100dvh] bg-indigo-950 flex flex-col pb-20 relative overflow-hidden">
      {/* Stars bg */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(white 1px, transparent 1px)', backgroundSize: '30px 30px' }} />

      {/* Animated Moon Face */}
      <div className="pt-12 pb-6 flex justify-center z-10 relative">
        <motion.div 
          animate={{ y: [0, -15, 0], rotate: [-2, 2, -2] }}
          transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
          className="w-32 h-32 bg-yellow-100 rounded-full shadow-[0_0_50px_rgba(253,224,71,0.4)] flex items-center justify-center relative overflow-hidden"
        >
          {/* Craters */}
          <div className="absolute top-4 right-4 w-6 h-6 bg-yellow-200/50 rounded-full" />
          <div className="absolute bottom-6 left-6 w-8 h-8 bg-yellow-200/50 rounded-full" />
          {/* Face */}
          <div className="flex gap-4 mb-2">
            <div className="w-3 h-3 bg-indigo-900 rounded-full" />
            <div className="w-3 h-3 bg-indigo-900 rounded-full" />
          </div>
          <div className="absolute top-1/2 mt-2 w-8 h-4 border-b-4 border-indigo-900 rounded-full" />
        </motion.div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 z-10" ref={scrollRef}>
        <AnimatePresence>
          {messages.map((m) => (
            <motion.div 
              key={m.id}
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] p-4 rounded-3xl ${
                m.sender === 'user' 
                  ? 'bg-yellow-400 text-indigo-950 rounded-br-none font-bold' 
                  : 'bg-indigo-800/80 backdrop-blur-md text-white border border-indigo-700 rounded-bl-none'
              }`}>
                <p className="text-lg">{m.text}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Quick Replies */}
      <div className="p-4 z-10 bg-indigo-950/80 backdrop-blur-md">
        {step === 0 && (
          <div className="grid grid-cols-2 gap-3">
            {["Perros", "Gatos", "Dinosaurios", "Pájaros"].map(opt => (
              <Button key={opt} variant="secondary" className="h-14 rounded-2xl text-lg font-bold bg-white text-indigo-900 hover:bg-yellow-100" onClick={() => handleReply(opt)}>
                {opt}
              </Button>
            ))}
          </div>
        )}
        {step === 1 && (
          <div className="grid grid-cols-2 gap-3">
            {["Azul", "Rojo", "Amarillo", "Verde"].map(opt => (
              <Button key={opt} variant="secondary" className="h-14 rounded-2xl text-lg font-bold bg-white text-indigo-900 hover:bg-yellow-100" onClick={() => handleReply(opt)}>
                {opt}
              </Button>
            ))}
          </div>
        )}
        {step >= 2 && (
          <div className="flex justify-center">
            <Button size="lg" className="w-full max-w-xs h-16 rounded-full text-xl bg-yellow-400 text-indigo-950 hover:bg-yellow-300 shadow-[0_0_20px_rgba(250,204,21,0.4)] flex gap-2">
              <Mic className="w-6 h-6" /> Hablar con Luna
            </Button>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
