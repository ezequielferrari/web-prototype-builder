import { useState } from "react";
import { BottomNav } from "../components/BottomNav";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { MascotCharacter } from "../components/MascotCharacter";
import { motion } from "framer-motion";
import confetti from "canvas-confetti";

export default function Lectura() {
  const [isRecording, setIsRecording] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleRecord = () => {
    setIsRecording(true);
    let p = 0;
    const interval = setInterval(() => {
      p += 33.3;
      setProgress(p);
      if (p >= 100) {
        clearInterval(interval);
        setIsRecording(false);
        setShowResult(true);
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
    }, 1000);
  };

  return (
    <div className="min-h-[100dvh] bg-background pb-24 flex flex-col">
      <div className="p-6 pt-12 flex-1 flex flex-col">
        <h1 className="text-2xl font-bold mb-6 text-center text-primary">¡A leer juntos!</h1>
        
        {!showResult ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-12">
            <Card className="w-full max-w-md p-8 border-none shadow-md bg-white rounded-3xl text-center">
              <h2 className="text-4xl font-extrabold text-foreground leading-tight">
                El oso come miel.
              </h2>
            </Card>

            <div className="relative">
              <motion.button
                whileTap={{ scale: 0.95 }}
                animate={isRecording ? { scale: [1, 1.1, 1], boxShadow: ["0px 0px 0px rgba(0,0,0,0)", "0px 0px 20px rgba(255,100,100,0.5)", "0px 0px 0px rgba(0,0,0,0)"] } : {}}
                transition={{ repeat: isRecording ? Infinity : 0, duration: 1.5 }}
                onClick={handleRecord}
                disabled={isRecording}
                className={`w-32 h-32 rounded-full flex items-center justify-center text-4xl shadow-lg transition-colors ${
                  isRecording ? "bg-red-500 text-white" : "bg-primary text-white"
                }`}
              >
                🎤
              </motion.button>
              {isRecording && (
                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-full text-center text-sm font-bold text-red-500 animate-pulse">
                  Grabando...
                </div>
              )}
            </div>

            {isRecording && (
              <div className="w-full max-w-xs mt-4">
                <Progress value={progress} className="h-3" />
              </div>
            )}
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }} 
            animate={{ opacity: 1, scale: 1 }} 
            className="flex-1 flex flex-col items-center justify-center gap-6"
          >
            <MascotCharacter size="lg" />
            <h2 className="text-3xl font-extrabold text-green-500 text-center">¡Excelente!</h2>
            <p className="text-lg font-medium text-center text-muted-foreground">Lo leíste muy bien.</p>
            
            <div className="flex gap-2 text-4xl mt-2 mb-4">
              <motion.span initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>⭐</motion.span>
              <motion.span initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>⭐</motion.span>
              <motion.span initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>⭐</motion.span>
            </div>

            <Button 
              size="lg" 
              className="w-full max-w-xs h-14 text-xl rounded-full bg-secondary text-secondary-foreground"
              onClick={() => { setShowResult(false); setProgress(0); }}
            >
              Otra frase
            </Button>
          </motion.div>
        )}
      </div>
      <BottomNav />
    </div>
  );
}

