import { useState, useEffect } from "react";
import { BottomNav } from "../components/BottomNav";
import { useAppContext } from "../context/AppContext";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function Bienestar() {
  const { state, setWellnessLimit } = useAppContext();
  const [limit, setLimit] = useState(state.wellnessLimit);

  const usagePercent = Math.min(100, (state.dailyUsageMinutes / state.wellnessLimit) * 100);

  const mockData = [
    { day: "Lun", min: 20 },
    { day: "Mar", min: 35 },
    { day: "Mie", min: 15 },
    { day: "Jue", min: 40 },
    { day: "Vie", min: state.dailyUsageMinutes },
    { day: "Sab", min: 0 },
    { day: "Dom", min: 0 },
  ];

  return (
    <div className="min-h-[100dvh] bg-background pb-24">
      <div className="p-6 pt-12 max-w-lg mx-auto">
        <h1 className="text-2xl font-bold mb-6 text-center text-primary">Bienestar Digital</h1>

        <Card className="mb-8 border-none shadow-sm rounded-3xl overflow-hidden">
          <CardContent className="p-6 flex flex-col items-center">
             <div className="relative w-48 h-48 mb-6 flex items-center justify-center">
               <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                 <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="10" fill="transparent" className="text-muted" />
                 <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="10" fill="transparent" className="text-primary transition-all duration-1000 ease-in-out" strokeDasharray={`${usagePercent * 2.51} 251`} />
               </svg>
               <div className="absolute flex flex-col items-center">
                 <span className="text-3xl font-extrabold text-foreground">{state.dailyUsageMinutes}</span>
                 <span className="text-sm font-bold text-muted-foreground">minutos hoy</span>
               </div>
             </div>
             
             <div className="w-full space-y-4">
               <div className="flex justify-between font-bold text-sm">
                 <span>Límite diario:</span>
                 <span className="text-primary">{limit} min</span>
               </div>
               <Slider 
                 value={[limit]} 
                 onValueChange={(val) => setLimit(val[0])} 
                 onValueCommit={(val) => setWellnessLimit(val[0])}
                 max={60} 
                 min={15} 
                 step={5} 
               />
             </div>
          </CardContent>
        </Card>

        <Card className="mb-8 border-none shadow-sm rounded-3xl overflow-hidden bg-gradient-to-r from-blue-50 to-cyan-50">
          <CardContent className="p-6">
            <h3 className="font-bold text-lg mb-2 flex items-center gap-2">💡 Tip de bienestar</h3>
            <p className="text-muted-foreground">Recuerda parpadear seguido y mirar por la ventana cada 20 minutos para descansar tus ojitos.</p>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-xl font-bold mb-4">Esta semana</h2>
          <Card className="border-none shadow-sm rounded-3xl p-4">
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mockData}>
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#888', fontSize: 12}} />
                  <Tooltip cursor={{fill: '#f4f4f5'}} contentStyle={{borderRadius: '1rem', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'}} />
                  <Bar dataKey="min" fill="hsl(var(--secondary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>

      </div>
      <BottomNav />
    </div>
  );
}
