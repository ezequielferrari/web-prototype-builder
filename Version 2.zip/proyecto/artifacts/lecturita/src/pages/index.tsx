import { useState } from "react";
import { useLocation } from "wouter";
import { useAppContext, ProfileType } from "../context/AppContext";
import { motion, AnimatePresence } from "framer-motion";
import { MascotCharacter } from "../components/MascotCharacter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Onboarding() {
  const [, setLocation] = useLocation();
  const { setProfileType, setChildProfile, setAdultProfile } = useAppContext();
  const [step, setStep] = useState(0); // 0: welcome, 1: profile select, 2: child, 3: adult
  const [childName, setChildName] = useState("");
  
  const handleStart = () => setStep(1);
  
  const handleSelectProfile = (type: ProfileType) => {
    setProfileType(type);
    if (type === "child") setStep(2);
    else if (type === "adult") setStep(3);
  };

  const handleFinishChild = () => {
    setChildProfile({
      name: childName || "Amigo",
      avatar: "🐶",
      age: "3-5",
      interests: ["animales"]
    });
    setLocation("/inicio");
  };

  const handleFinishAdult = () => {
    setAdultProfile({
      childName: childName || "Mi niño",
      childAge: "4",
      level: "intermedio",
      maxDailyUsage: 30
    });
    setLocation("/familias");
  };

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col items-center justify-center p-6 text-center">
      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="step0" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="flex flex-col items-center gap-6">
            <img
              src={`${import.meta.env.BASE_URL}panka-logo.png`}
              alt="Panka — Cada palabra abre un mundo"
              className="w-full max-w-[340px] h-auto object-contain"
            />
            <div>
              <h1 className="sr-only">Panka</h1>
              <p className="text-muted-foreground text-lg">Aprender a leer es mágico</p>
            </div>
            <Button size="lg" className="w-full max-w-xs h-14 text-xl rounded-full mt-4" onClick={handleStart}>
              ¡Comenzar!
            </Button>
          </motion.div>
        )}
        
        {step === 1 && (
          <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="w-full max-w-sm flex flex-col gap-4">
            <h2 className="text-2xl font-bold mb-4">¿Quién eres?</h2>
            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={() => handleSelectProfile("child")}
                className="bg-card hover:bg-primary/10 border-2 border-transparent hover:border-primary p-6 rounded-3xl flex flex-col items-center gap-3 transition-colors shadow-sm"
              >
                <div className="text-5xl">🧒</div>
                <span className="font-bold text-lg">Soy niño/a</span>
              </button>
              <button 
                onClick={() => handleSelectProfile("adult")}
                className="bg-card hover:bg-secondary/10 border-2 border-transparent hover:border-secondary p-6 rounded-3xl flex flex-col items-center gap-3 transition-colors shadow-sm"
              >
                <div className="text-5xl">👨‍👩‍👧</div>
                <span className="font-bold text-lg">Soy adulto</span>
              </button>
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="w-full max-w-sm flex flex-col gap-6">
            <h2 className="text-2xl font-bold">¡Hola! ¿Cómo te llamas?</h2>
            <MascotCharacter size="md" className="mx-auto" />
            <Input 
              value={childName}
              onChange={(e) => setChildName(e.target.value)}
              placeholder="Tu nombre..."
              className="h-16 text-2xl text-center rounded-2xl"
            />
            <Button size="lg" className="w-full h-14 text-xl rounded-full" onClick={handleFinishChild}>
              ¡A Jugar!
            </Button>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="w-full max-w-sm flex flex-col gap-6 text-left">
            <h2 className="text-2xl font-bold text-center">Configuración de Adulto</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-semibold mb-1 block">Nombre de tu niño/a</label>
                <Input value={childName} onChange={(e) => setChildName(e.target.value)} placeholder="Ej: Sofía" className="h-12 rounded-xl" />
              </div>
            </div>
            <Button size="lg" className="w-full h-14 text-xl rounded-full mt-4 bg-secondary text-secondary-foreground hover:bg-secondary/90" onClick={handleFinishAdult}>
              Guardar Perfil
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
