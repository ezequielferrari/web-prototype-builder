import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type ProfileType = "child" | "adult" | null;
export type AgeGroup = "0-2" | "3-5" | "6-7";
export type Level = "inicial" | "intermedio" | "avanzado";

export interface ChildProfile {
  name: string;
  avatar: string;
  age: AgeGroup;
  interests: string[];
}

export interface AdultProfile {
  childName: string;
  childAge: string;
  level: Level;
  maxDailyUsage: number;
}

export interface Story {
  id: string;
  title: string;
  author: string;
  ageRange: string;
  level: Level;
  coverColor: string;
  coverEmoji: string;
}

export interface AppState {
  profileType: ProfileType;
  childProfile: ChildProfile | null;
  adultProfile: AdultProfile | null;
  dailyUsageMinutes: number;
  streak: number;
  favorites: string[];
  reflections: { date: string; text: string }[];
  completedActivities: string[];
  wellnessLimit: number;
  customStories: any[];
}

interface AppContextType {
  state: AppState;
  setProfileType: (type: ProfileType) => void;
  setChildProfile: (profile: ChildProfile) => void;
  setAdultProfile: (profile: AdultProfile) => void;
  updateUsage: (minutes: number) => void;
  incrementStreak: () => void;
  toggleFavorite: (storyId: string) => void;
  addReflection: (text: string) => void;
  markActivityComplete: (id: string) => void;
  setWellnessLimit: (limit: number) => void;
  saveCustomStory: (story: any) => void;
  resetAll: () => void;
}

const defaultState: AppState = {
  profileType: null,
  childProfile: null,
  adultProfile: null,
  dailyUsageMinutes: 0,
  streak: 0,
  favorites: [],
  reflections: [],
  completedActivities: [],
  wellnessLimit: 30,
  customStories: [],
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(() => {
    try {
      const saved = localStorage.getItem("lecturita_state");
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error("Failed to load state", e);
    }
    return defaultState;
  });

  useEffect(() => {
    localStorage.setItem("lecturita_state", JSON.stringify(state));
  }, [state]);

  const setProfileType = (type: ProfileType) => setState((s) => ({ ...s, profileType: type }));
  const setChildProfile = (profile: ChildProfile) => setState((s) => ({ ...s, childProfile: profile }));
  const setAdultProfile = (profile: AdultProfile) => setState((s) => ({ ...s, adultProfile: profile }));
  const updateUsage = (minutes: number) => setState((s) => ({ ...s, dailyUsageMinutes: s.dailyUsageMinutes + minutes }));
  const incrementStreak = () => setState((s) => ({ ...s, streak: s.streak + 1 }));
  const toggleFavorite = (storyId: string) => setState((s) => ({
    ...s,
    favorites: s.favorites.includes(storyId) 
      ? s.favorites.filter((id) => id !== storyId)
      : [...s.favorites, storyId]
  }));
  const addReflection = (text: string) => setState((s) => ({
    ...s,
    reflections: [{ date: new Date().toISOString(), text }, ...s.reflections]
  }));
  const markActivityComplete = (id: string) => setState((s) => ({
    ...s,
    completedActivities: s.completedActivities.includes(id) ? s.completedActivities : [...s.completedActivities, id]
  }));
  const setWellnessLimit = (limit: number) => setState((s) => ({ ...s, wellnessLimit: limit }));
  const saveCustomStory = (story: any) => setState((s) => ({ ...s, customStories: [story, ...s.customStories] }));
  const resetAll = () => setState(defaultState);

  return (
    <AppContext.Provider value={{
      state,
      setProfileType,
      setChildProfile,
      setAdultProfile,
      updateUsage,
      incrementStreak,
      toggleFavorite,
      addReflection,
      markActivityComplete,
      setWellnessLimit,
      saveCustomStory,
      resetAll
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useAppContext must be used within AppProvider");
  return context;
}
