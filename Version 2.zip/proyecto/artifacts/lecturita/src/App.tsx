import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { AppProvider } from "./context/AppContext";

import Onboarding from "./pages/index";
import Home from "./pages/inicio";
import Diagnostico from "./pages/diagnostico";
import Bienestar from "./pages/bienestar";
import Metacognicion from "./pages/metacognicion";
import Actividades from "./pages/actividades";
import Chat from "./pages/chat";
import Biblioteca from "./pages/biblioteca";
import Lectura from "./pages/lectura";
import Familias from "./pages/familias";
import Crear from "./pages/crear";
import Amigo from "./pages/amigo";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Onboarding} />
      <Route path="/inicio" component={Home} />
      <Route path="/diagnostico" component={Diagnostico} />
      <Route path="/bienestar" component={Bienestar} />
      <Route path="/metacognicion" component={Metacognicion} />
      <Route path="/actividades" component={Actividades} />
      <Route path="/chat" component={Chat} />
      <Route path="/biblioteca" component={Biblioteca} />
      <Route path="/lectura" component={Lectura} />
      <Route path="/familias" component={Familias} />
      <Route path="/crear" component={Crear} />
      <Route path="/amigo" component={Amigo} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </AppProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
