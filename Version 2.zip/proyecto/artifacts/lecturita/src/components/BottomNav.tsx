import { Link, useLocation } from "wouter";
import { Home, Book, Mic, Pencil, Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/inicio", icon: Home, label: "Inicio" },
    { href: "/biblioteca", icon: Book, label: "Biblioteca" },
    { href: "/lectura", icon: Mic, label: "Lectura" },
    { href: "/crear", icon: Pencil, label: "Crear" },
    { href: "/amigo", icon: Star, label: "Amigo" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 pb-safe z-50 px-2 py-2">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div className="flex flex-col items-center justify-center w-16 h-14 rounded-xl active:scale-95 transition-transform cursor-pointer">
                <div className={cn(
                  "p-2 rounded-full mb-1 transition-colors",
                  isActive ? "bg-primary/10 text-primary" : "text-gray-400"
                )}>
                  <item.icon className="w-6 h-6" strokeWidth={isActive ? 2.5 : 2} />
                </div>
                <span className={cn(
                  "text-[10px] font-bold transition-colors",
                  isActive ? "text-primary" : "text-gray-400"
                )}>
                  {item.label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
