import { motion } from "framer-motion";

export function MascotCharacter({ className = "", size = "md" }: { className?: string, size?: "sm" | "md" | "lg" }) {
  const sizes = {
    sm: "w-12 h-12",
    md: "w-24 h-24",
    lg: "w-32 h-32"
  };

  return (
    <motion.div 
      className={`relative ${sizes[size]} ${className}`}
      animate={{ y: [0, -10, 0] }}
      transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary to-orange-500 rounded-[40%] shadow-lg overflow-hidden flex items-center justify-center">
        <div className="flex gap-2 mb-2">
          {/* Eyes */}
          <div className="w-4 h-4 rounded-full bg-white flex items-center justify-center">
            <motion.div 
              className="w-1.5 h-1.5 bg-gray-900 rounded-full"
              animate={{ x: [-1, 1, -1] }}
              transition={{ repeat: Infinity, duration: 3 }}
            />
          </div>
          <div className="w-4 h-4 rounded-full bg-white flex items-center justify-center">
            <motion.div 
              className="w-1.5 h-1.5 bg-gray-900 rounded-full"
              animate={{ x: [-1, 1, -1] }}
              transition={{ repeat: Infinity, duration: 3 }}
            />
          </div>
        </div>
        {/* Beak */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 w-3 h-3 bg-yellow-300 rotate-45 rounded-sm" />
        
        {/* Blushes */}
        <div className="absolute top-1/2 left-3 w-2 h-1.5 bg-pink-400/50 rounded-full blur-[1px]" />
        <div className="absolute top-1/2 right-3 w-2 h-1.5 bg-pink-400/50 rounded-full blur-[1px]" />
      </div>
    </motion.div>
  );
}
